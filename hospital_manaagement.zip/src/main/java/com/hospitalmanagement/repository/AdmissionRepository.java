package com.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.entity.Admission;

public interface AdmissionRepository extends JpaRepository<Admission, Long>{

}
