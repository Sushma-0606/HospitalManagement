package com.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.entity.Ward;

public interface WardRepository extends JpaRepository<Ward, Long>{

}
