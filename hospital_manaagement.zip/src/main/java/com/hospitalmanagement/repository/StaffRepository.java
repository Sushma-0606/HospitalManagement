package com.hospitalmanagement.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.entity.Staff;

public interface StaffRepository extends JpaRepository<Staff, Long>{

	Set<Staff> findByidIn(Set<Long> ids);

}
