package com.hospitalmanagement.repository;

import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.entity.Doctor;

public interface DoctorRepository extends JpaRepository<Doctor, Long>{

	Set<Doctor> findByIdIn(Set<Long> ids);

}
