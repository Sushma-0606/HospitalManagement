package com.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.entity.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Long>{

}
