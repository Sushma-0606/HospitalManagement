package com.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.entity.User;

public interface UserRepository extends JpaRepository<User, Long>{

}
