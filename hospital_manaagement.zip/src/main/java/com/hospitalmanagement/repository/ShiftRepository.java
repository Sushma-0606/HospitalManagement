package com.hospitalmanagement.repository;

import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.entity.Shift;

public interface ShiftRepository extends JpaRepository<Shift, Long>{

	List<Shift> findByIdIn(Set<Long> ids);

}
