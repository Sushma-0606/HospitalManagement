package com.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.entity.TestResult;

public interface TestResultRepository extends JpaRepository<TestResult, Long>{

}
