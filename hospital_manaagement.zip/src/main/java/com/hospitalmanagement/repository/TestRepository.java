package com.hospitalmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hospitalmanagement.entity.Test;

public interface TestRepository extends JpaRepository<Test, Long>{

}
