package com.hospitalmanagement.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalmanagement.request.PrescriptionRequest;
import com.hospitalmanagement.response.PrescriptionResponse;
import com.hospitalmanagement.service.PrescriptionService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@RestController
@RequestMapping("/api/v1/prescription")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PrescriptionRestController {

	@Autowired
	PrescriptionService prescriptionService;

	@GetMapping
	public List<PrescriptionResponse> getAllPrescriptions() {
		return prescriptionService.findAll();
	}
	
	@PostMapping
	public ResponseEntity<Object> createPrescription(@RequestBody PrescriptionRequest prescriptionRequest) {
		try {
			PrescriptionResponse prescriptionResponse = prescriptionService.save(prescriptionRequest);
			return ResponseEntity.status(HttpStatus.CREATED).body(prescriptionResponse);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> getPrescriptionById(@PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.FOUND).body(prescriptionService.findById(id));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deletePrescription(@PathVariable Long id) {
		try {
			prescriptionService.deleteById(id);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}
}
