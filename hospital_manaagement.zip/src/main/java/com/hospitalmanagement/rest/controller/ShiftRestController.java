package com.hospitalmanagement.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalmanagement.request.ShiftRequest;
import com.hospitalmanagement.response.ShiftResponse;
import com.hospitalmanagement.service.ShiftService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@RestController
@RequestMapping("/api/v1/shift")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ShiftRestController {
	
	@Autowired ShiftService shiftService;

	 @GetMapping
	    public List<ShiftResponse> getAllShifts() {
	        return shiftService.findAll();
	    }
	 
	 @PostMapping
		public ResponseEntity<Object> createShift(@RequestBody ShiftRequest shiftRequest) {
			try {
				ShiftResponse shiftResponse = shiftService.save(shiftRequest);
				return ResponseEntity.status(HttpStatus.CREATED).body(shiftResponse);
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
			}
		}

		@GetMapping("/{id}")
		public ResponseEntity<Object> getShiftById(@PathVariable Long id) {
			try {
				return ResponseEntity.status(HttpStatus.FOUND).body(shiftService.findById(id));
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
			}
		}

		@DeleteMapping("/{id}")
		public ResponseEntity<Object> deleteShift(@PathVariable Long id) {
			try {
				shiftService.deleteById(id);
				return ResponseEntity.noContent().build();
			} catch (Exception e) {
				return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
			}
		}
}
