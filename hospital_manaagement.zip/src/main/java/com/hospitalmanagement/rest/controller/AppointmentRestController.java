package com.hospitalmanagement.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalmanagement.request.AppointmentRequest;
import com.hospitalmanagement.response.AppointmentResponse;
import com.hospitalmanagement.service.AppointmentService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@RestController
@RequestMapping("/api/v1/apointment")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AppointmentRestController {

	@Autowired
	AppointmentService apointmentService;

	@GetMapping
	public List<AppointmentResponse> getAllAppointments() {
		return apointmentService.findAll();
	}

	@PostMapping
	public ResponseEntity<Object> createAppointment(@RequestBody AppointmentRequest appointmentRequest) {
		try {
			return ResponseEntity.status(HttpStatus.CREATED).body(apointmentService.save(appointmentRequest));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Object> getAppointmentById(@PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.FOUND).body(apointmentService.findById(id));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteAppointment(@PathVariable Long id) {
		try {
			apointmentService.deleteById(id);
			return ResponseEntity.status(HttpStatus.FOUND).build();
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}
	 
}
