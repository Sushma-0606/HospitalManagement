package com.hospitalmanagement.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalmanagement.request.TestRequest;
import com.hospitalmanagement.response.TestResponse;
import com.hospitalmanagement.service.TestService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@RestController
@RequestMapping("/api/v1/test")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class TestRestController {

	@Autowired
	TestService testService;

	@GetMapping
	public ResponseEntity<List<TestResponse>> getAllTests() {
		List<TestResponse> testResponses = testService.findAll();
		return new ResponseEntity<>(testResponses, HttpStatus.OK);
	}
	
	@PostMapping
	public ResponseEntity<Object> createTest(@RequestBody TestRequest testRequest) {
		try {
			TestResponse testResponse = testService.save(testRequest);
			return ResponseEntity.status(HttpStatus.CREATED).body(testResponse);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> getTestById(@PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.FOUND).body(testService.findById(id));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteTest(@PathVariable Long id) {
		try {
			testService.deleteById(id);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}
}
