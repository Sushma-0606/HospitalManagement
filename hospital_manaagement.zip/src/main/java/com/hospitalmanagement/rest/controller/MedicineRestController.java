package com.hospitalmanagement.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalmanagement.request.MedicineRequest;
import com.hospitalmanagement.response.MedicineResposne;
import com.hospitalmanagement.service.MedicineService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@RestController
@RequestMapping("/api/v1/medicine")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MedicineRestController {

	@Autowired
	MedicineService medicineService;

	@GetMapping
	public List<MedicineResposne> getAllMedicines() {
		return medicineService.findAll();
	}

	@PostMapping
	public ResponseEntity<Object> createMedicine(@RequestBody MedicineRequest medicineRequest) {
		try {
			return ResponseEntity.ok(medicineService.save(medicineRequest));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}

	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> getAdmissionById(@PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.FOUND).body(medicineService.findById(id));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteAdmission(@PathVariable Long id) {
		try {
			medicineService.deleteById(id);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}
}
