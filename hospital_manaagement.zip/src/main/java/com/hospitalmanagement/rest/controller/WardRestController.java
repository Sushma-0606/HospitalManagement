package com.hospitalmanagement.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hospitalmanagement.request.WardRequest;
import com.hospitalmanagement.response.WardResponse;
import com.hospitalmanagement.service.WardService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@RestController
@RequestMapping("/api/v1/ward")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class WardRestController {

	@Autowired
	WardService wardService;

	@GetMapping
	public List<WardResponse> getAllAdmissions() {
		return wardService.findAll();
	}

	@PostMapping
	public ResponseEntity<Object> createWard(@RequestBody WardRequest wardRequest) {
		try {
			WardResponse wardResponse = wardService.save(wardRequest);
			return ResponseEntity.status(HttpStatus.CREATED).body(wardResponse);
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}

	@GetMapping("/{id}")
	public ResponseEntity<Object> getWardById(@PathVariable Long id) {
		try {
			return ResponseEntity.status(HttpStatus.FOUND).body(wardService.findById(id));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Object> deleteWard(@PathVariable Long id) {
		try {
			wardService.deleteById(id);
			return ResponseEntity.noContent().build();
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMessage());
		}
	}

}
