package com.hospitalmanagement.custom.repository;

public interface UserCustomRepository {

}
