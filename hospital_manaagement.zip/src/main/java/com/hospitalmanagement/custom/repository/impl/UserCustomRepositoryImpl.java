package com.hospitalmanagement.custom.repository.impl;

import org.springframework.stereotype.Repository;
import com.hospitalmanagement.custom.repository.UserCustomRepository;

@Repository
public class UserCustomRepositoryImpl implements UserCustomRepository {

	
}
