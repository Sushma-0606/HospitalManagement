package com.hospitalmanagement;

import org.springframework.web.bind.annotation.ControllerAdvice;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@ControllerAdvice
@Setter
@Getter
@NoArgsConstructor
public class HospitalManagementException extends Exception {

	private static final long serialVersionUID = 1L;

	public HospitalManagementException(Exception e) {
		super(e);
	}

	public HospitalManagementException(String message) {
		super(message);
	}

	public HospitalManagementException(Throwable throwable) {
		super(throwable);
	}
}
