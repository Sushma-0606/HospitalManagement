package com.hospitalmanagement.request;

import java.time.LocalTime;
import java.util.Set;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ShiftRequest {
	Long id;
	String name;
	LocalTime startTime;
	LocalTime endTime;
	Set<Long> staffIds;
    Set<Long> doctorIds;

}
