package com.hospitalmanagement.request;

import java.util.Date;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AdmissionRequest {

	Long id;
	Long patientId;
	Long wardId;
	Date admissionDateTime;
	Date dischargeDateTime;
}
