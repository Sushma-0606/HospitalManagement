package com.hospitalmanagement.service;

import java.util.List;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.request.TestResultRequest;
import com.hospitalmanagement.response.TestResultResponse;

public interface TestResultService {

	List<TestResultResponse> findAll();

	TestResultResponse findById(Long id) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;

	TestResultResponse save(TestResultRequest testResultRequest) throws HospitalManagementException;

}
