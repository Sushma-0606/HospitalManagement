package com.hospitalmanagement.service;

import java.util.List;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.request.PrescriptionRequest;
import com.hospitalmanagement.response.PrescriptionResponse;

public interface PrescriptionService {

	List<PrescriptionResponse> findAll();

	PrescriptionResponse findById(Long id) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;

	PrescriptionResponse save(PrescriptionRequest prescriptionRequest) throws HospitalManagementException;

}
