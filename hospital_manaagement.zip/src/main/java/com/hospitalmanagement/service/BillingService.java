package com.hospitalmanagement.service;

import java.util.List;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Billing;
import com.hospitalmanagement.request.BillingRequest;
import com.hospitalmanagement.response.BillingResponse;

public interface BillingService {

	List<BillingResponse> findAll();

	BillingResponse createOrUpdate(BillingRequest billingRequest)throws HospitalManagementException;

	BillingResponse findById(Long id);

	void deleteById(Long id);

	Billing findByIdWithException(Long id) throws HospitalManagementException;

}
