package com.hospitalmanagement.service;

import java.util.List;

import com.hospitalmanagement.entity.Admission;
import com.hospitalmanagement.request.AdmissionRequest;
import com.hospitalmanagement.response.AdmissionResponse;

public interface AdmissionService {

	List<Admission> findAll();

	AdmissionResponse save(AdmissionRequest admissionRequest);

	AdmissionResponse findById(Long id);

	void deleteById(Long id);

}
