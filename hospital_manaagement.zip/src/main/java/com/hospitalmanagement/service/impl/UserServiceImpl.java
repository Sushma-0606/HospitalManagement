package com.hospitalmanagement.service.impl;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.User;
import com.hospitalmanagement.helper.UserHelper;
import com.hospitalmanagement.repository.UserRepository;
import com.hospitalmanagement.request.UserRequest;
import com.hospitalmanagement.response.UserResponse;
import com.hospitalmanagement.service.UserService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class UserServiceImpl implements UserService {

	@Autowired UserRepository userRepository;
	@Autowired UserHelper userHelper;

	@Override
	public List<UserResponse> findAll() {
		return userRepository.findAll().stream().map(userHelper::getUserResponse).toList();
	}

	@Override
	public UserResponse findById(Long id) throws HospitalManagementException {
		User user = userRepository.findById(id).orElseThrow(() -> new HospitalManagementException("User Not Found# " + id));
		return userHelper.getUserResponse(user);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		User user = userRepository.findById(id).orElseThrow(() -> new HospitalManagementException("User Not Found# " + id));
		userRepository.deleteById(user.getId());
	}

	@Override
	public UserResponse save(UserRequest userRequest) throws HospitalManagementException {
		User user = new User();
		if (userRequest.getId() != null) {
			user = userRepository.findById(userRequest.getId()).orElseThrow(() -> new HospitalManagementException("User Not Found# " + userRequest.getId()));
		}
		user.setPassword(userRequest.getPassword());
		user.setUsername(userRequest.getUsername());
		user.setCreatedOn(LocalDateTime.now());
		userRepository.save(user);
		return userHelper.getUserResponse(user);
	}
}
