package com.hospitalmanagement.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Department;
import com.hospitalmanagement.helper.DepartmentHelper;
import com.hospitalmanagement.repository.DepartmentRepository;
import com.hospitalmanagement.request.DepartmentRequest;
import com.hospitalmanagement.response.DepartmentResponse;
import com.hospitalmanagement.service.DepartmentService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	DepartmentRepository departmentRepository;

	@Autowired
	DepartmentHelper departmentHelper;

	@Override
	public List<DepartmentResponse> findAll() {
		return departmentRepository.findAll().stream().map(departmentHelper::getDepartmentResponse).toList();
	}

	@Override
	public DepartmentResponse findById(Long id) throws HospitalManagementException {
		return departmentHelper.getDepartmentResponse(departmentRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Department Not Found# " + id)));
	}

	@Override
	public DepartmentResponse save(DepartmentRequest departmentRequest) throws HospitalManagementException {
		Department department = new Department();
		if (departmentRequest.getId() != null) {
			department = departmentRepository.findById(departmentRequest.getId()).orElseThrow(
					() -> new HospitalManagementException("Department Not Found# " + departmentRequest.getId()));
		}
		department.setName(departmentRequest.getName());
		departmentRepository.save(department);
		return departmentHelper.getDepartmentResponse(department);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		Department existingDepartment = departmentRepository.findById(id).orElseThrow(
				() -> new HospitalManagementException("Department Not Found# " + id));
		departmentRepository.delete(existingDepartment);
	}

	@Override
	public Optional<Department> findOptionalDepartmentById(Long id) {
		return departmentRepository.findById(id);
	}
}
