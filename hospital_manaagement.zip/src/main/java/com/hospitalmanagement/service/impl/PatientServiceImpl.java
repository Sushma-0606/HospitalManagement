package com.hospitalmanagement.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Patient;
import com.hospitalmanagement.helper.PatientHelper;
import com.hospitalmanagement.repository.PatientRepository;
import com.hospitalmanagement.request.PatientRequest;
import com.hospitalmanagement.response.PatientResponse;
import com.hospitalmanagement.service.DepartmentService;
import com.hospitalmanagement.service.PatientService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PatientServiceImpl implements PatientService {

	@Autowired
	PatientRepository patientRepository;

	@Autowired
	PatientHelper patientHelper;
	
	@Autowired
	DepartmentService departmentService;

	@Override
	public Optional<Patient> findOptionalById(Long id) {
		return patientRepository.findById(id);
	}

	@Override
	public List<PatientResponse> findAll() {
		return patientRepository.findAll().stream().map(patientHelper::getPatientResponse).toList();
	}

	@Override
	public PatientResponse findById(Long id) throws HospitalManagementException {
		Patient patient = patientRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Patient Not Found# " + id));
		return patientHelper.getPatientResponse(patient);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		Patient patient = patientRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Patient Not Found# " + id));
		patientRepository.deleteById(patient.getId());
	}

	@Override
	public PatientResponse save(PatientRequest patientRequest) throws HospitalManagementException {
		Patient patient = new Patient();
		if (patientRequest.getId() != null) {
			patient = patientRepository.findById(patientRequest.getId())
					.orElseThrow(() -> new HospitalManagementException("Patient Not Found# " + patientRequest.getId()));
		}
		patient.setName(patientRequest.getName());
		patient.setAddress(patientRequest.getAddress());
		if (patientRequest.getDepartmentId() != null) {
			patient.setDepartment(departmentService.findOptionalDepartmentById(patientRequest.getDepartmentId())
					.orElseThrow(() -> new HospitalManagementException(
							"Department Not Found# " + patientRequest.getDepartmentId())));
		}
		patientRepository.save(patient);
		return patientHelper.getPatientResponse(patient);
	}
}
