package com.hospitalmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Transaction;
import com.hospitalmanagement.helper.TransactionHelper;
import com.hospitalmanagement.repository.TransactionRepository;
import com.hospitalmanagement.request.TransactionRequest;
import com.hospitalmanagement.response.TransactionResponse;
import com.hospitalmanagement.service.BillingService;
import com.hospitalmanagement.service.TransactionService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	TransactionRepository transactionRepository;
	@Autowired
	TransactionHelper transactionHelper;
	@Autowired
	BillingService billingService;

	@Override
	public List<TransactionResponse> findAll() {
		return transactionRepository.findAll().stream().map(transactionHelper::getTransactionResponse).toList();
	}

	@Override
	public TransactionResponse findById(Long id) throws HospitalManagementException {
		Transaction transaction = transactionRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Transaction Not Found# " + id));
		return transactionHelper.getTransactionResponse(transaction);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		Transaction transaction = transactionRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Transaction Not Found# " + id));
		transactionRepository.deleteById(transaction.getId());
	}

	@Override
	public TransactionResponse save(TransactionRequest transactionRequest) throws HospitalManagementException {
		Transaction transaction = new Transaction();
		if (transactionRequest.getId() != null) {
			transaction = transactionRepository.findById(transactionRequest.getId())
					.orElseThrow(() -> new HospitalManagementException("Transaction Not Found# " + transactionRequest.getId()));
		}
		validateTransactionRequest(transactionRequest);
		transaction.setAmount(transactionRequest.getAmount());
		transaction.setBilling(billingService.findByIdWithException(transactionRequest.getBillingId()));
		transaction.setTransactionDateTime(transactionRequest.getTransactionDateTime());
		transactionRepository.save(transaction);
		return transactionHelper.getTransactionResponse(transaction);
	}

	private void validateTransactionRequest(TransactionRequest transactionRequest) throws HospitalManagementException {
		if (transactionRequest.getBillingId() == null)
			throw new HospitalManagementException("Billing Id is Required");
	}

}
