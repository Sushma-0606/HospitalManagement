package com.hospitalmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.TestResult;
import com.hospitalmanagement.helper.TestResultHelper;
import com.hospitalmanagement.repository.TestResultRepository;
import com.hospitalmanagement.request.TestResultRequest;
import com.hospitalmanagement.response.TestResultResponse;
import com.hospitalmanagement.service.AppointmentService;
import com.hospitalmanagement.service.TestResultService;
import com.hospitalmanagement.service.TestService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class TestResultServiceImpl implements TestResultService {

	@Autowired
	TestResultRepository testResultRepository;
	@Autowired
	TestResultHelper testResultHelper;
	@Autowired
	AppointmentService appointmentService;
	@Autowired
	TestService testService;

	@Override
	public List<TestResultResponse> findAll() {
		return testResultRepository.findAll().stream().map(testResultHelper::getTestResultResponse).toList();
	}

	@Override
	public TestResultResponse save(TestResultRequest testResultRequest) throws HospitalManagementException {
		TestResult testResult = new TestResult();
		if (testResultRequest.getId() != null) {
			testResult = testResultRepository.findById(testResultRequest.getId()).orElseThrow(
					() -> new HospitalManagementException("TestResult Not Found" + testResultRequest.getId()));
		}
		vaildateTestResultRequest(testResultRequest);
		testResult.setAppointment(appointmentService.findByIdWithException(testResultRequest.getAppointmentId()));
		testResult.setTest(testService.findByIdWithException(testResultRequest.getTestId()));
		testResult.setResultDateTime(testResultRequest.getResultDateTime());
		testResult.setResultText(testResultRequest.getResultText());
		testResultRepository.save(testResult);
		return testResultHelper.getTestResultResponse(testResult);
	}

	private void vaildateTestResultRequest(TestResultRequest testResultRequest) {
		if (testResultRequest.getAppointmentId() == null || testResultRequest.getTestId() == null)
			throw new IllegalArgumentException("Appointment and Test Id Required");
	}

	@Override
	public TestResultResponse findById(Long id) throws HospitalManagementException {
		TestResult testResult = testResultRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("TestResult Not Found" + id));
		return testResultHelper.getTestResultResponse(testResult);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		TestResult testResult = testResultRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("TestResult Not Found" + id));
		testResultRepository.deleteById(testResult.getId());
	}

}
