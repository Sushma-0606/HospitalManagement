package com.hospitalmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Medicine;
import com.hospitalmanagement.helper.MedicineHelper;
import com.hospitalmanagement.repository.MedicineRepository;
import com.hospitalmanagement.request.MedicineRequest;
import com.hospitalmanagement.response.MedicineResposne;
import com.hospitalmanagement.service.MedicineService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class MedicineServiceImpl implements MedicineService {

	@Autowired
	MedicineRepository medicineRepository;

	@Autowired
	MedicineHelper medicineHelper;

	@Override
	public List<MedicineResposne> findAll() {
		return medicineRepository.findAll().stream().map(medicineHelper::getMedicineResposne).toList();
	}

	@Override
	public MedicineResposne save(MedicineRequest medicineRequest) throws HospitalManagementException {
		Medicine medicine = new Medicine();
		if (medicineRequest.getId() != null) {
			medicine = medicineRepository.findById(medicineRequest.getId()).orElseThrow(
					() -> new HospitalManagementException("Medicine Not Found# " + medicineRequest.getId()));
		}
		medicine.setName(medicineRequest.getName());
		medicine.setDescription(medicineRequest.getDescription());
		medicineRepository.save(medicine);
		return medicineHelper.getMedicineResposne(medicine);
	}

	@Override
	public MedicineResposne findById(Long id) throws HospitalManagementException {
		Medicine medicine = medicineRepository.findById(id).orElseThrow(
				() -> new HospitalManagementException("Medicine Not Found# " + id));
		return medicineHelper.getMedicineResposne(medicine);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		Medicine medicine = medicineRepository.findById(id).orElseThrow(
				() -> new HospitalManagementException("Medicine Not Found# " + id));
		medicineRepository.deleteById(medicine.getId());
	}
}
