package com.hospitalmanagement.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Doctor;
import com.hospitalmanagement.entity.Shift;
import com.hospitalmanagement.entity.Staff;
import com.hospitalmanagement.helper.ShiftHelper;
import com.hospitalmanagement.repository.ShiftRepository;
import com.hospitalmanagement.request.ShiftRequest;
import com.hospitalmanagement.response.ShiftResponse;
import com.hospitalmanagement.service.DoctorService;
import com.hospitalmanagement.service.ShiftService;
import com.hospitalmanagement.service.StaffService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class ShiftServiceImpl implements ShiftService {

	@Autowired
	ShiftRepository shiftRepository;
	@Autowired
	ShiftHelper shiftHelper;

	private final DoctorService doctorService;

	@Autowired
	public ShiftServiceImpl(DoctorService doctorService) {
	    this.doctorService = doctorService;
	}

	@Autowired
	StaffService staffService;

	@Override
	public List<Shift> findAllById(Set<Long> ids) {
		return shiftRepository.findByIdIn(ids);
	}

	@Override
	public Optional<Shift> findOptionalById(Long id) {
		return shiftRepository.findById(id);
	}

	@Override
	public List<ShiftResponse> findAll() {
		return shiftRepository.findAll().stream().map(shiftHelper::getShiftResponse).toList();
	}

	@Override
	public ShiftResponse findById(Long id) throws HospitalManagementException {
		Shift shift = shiftRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Shift Not Found# " + id));
		return shiftHelper.getShiftResponse(shift);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		Shift shift = shiftRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Shift Not Found# " + id));
		shiftRepository.deleteById(shift.getId());
	}

	@Override
	public ShiftResponse save(ShiftRequest shiftRequest) throws HospitalManagementException {
		Shift shift = new Shift();
		if (shiftRequest.getId() != null) {
			shift = shiftRepository.findById(shiftRequest.getId())
					.orElseThrow(() -> new HospitalManagementException("Shift Not Found# " + shiftRequest.getId()));
		}
		shift.setName(shiftRequest.getName());
		shift.setStartTime(shiftRequest.getStartTime());
		shift.setEndTime(shiftRequest.getEndTime());
		Set<Staff> staff = staffService.findAllById(shiftRequest.getStaffIds());
		if (staff.size() != shiftRequest.getStaffIds().size()) {
			throw new IllegalArgumentException("One or more staff members not found");
		}
		shift.setStaff(staff);

		Set<Doctor> doctors = doctorService.findAllById(shiftRequest.getDoctorIds());
		if (doctors.size() != shiftRequest.getDoctorIds().size()) {
			throw new IllegalArgumentException("One or more doctors not found");
		}
		shift.setDoctors(doctors);

		shiftRepository.save(shift);
		return shiftHelper.getShiftResponse(shift);
	}
}
