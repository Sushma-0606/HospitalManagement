package com.hospitalmanagement.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Doctor;
import com.hospitalmanagement.entity.Shift;
import com.hospitalmanagement.helper.DoctorHelper;
import com.hospitalmanagement.repository.DoctorRepository;
import com.hospitalmanagement.request.DoctorRequest;
import com.hospitalmanagement.response.DoctorResponse;
import com.hospitalmanagement.service.DepartmentService;
import com.hospitalmanagement.service.DoctorService;
import com.hospitalmanagement.service.ShiftService;
import com.hospitalmanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DoctorServiceImpl implements DoctorService {

	@Autowired
	DoctorRepository doctorRepository;

	@Autowired
	DoctorHelper doctorHelper;

	@Autowired
	DepartmentService departmentService;

	@Autowired
	private ShiftService shiftService;

	@Override
	public Optional<Doctor> findOptionalById(Long id) {
		return doctorRepository.findById(id);
	}

	@Override
	public List<DoctorResponse> findAll() {
		return doctorRepository.findAll().stream().map(doctorHelper::getDoctorResponse).toList();
	}

	@Override
	public DoctorResponse save(DoctorRequest doctorRequest) throws HospitalManagementException {
		Doctor doctor = new Doctor();
		if (doctorRequest.getId() != null) {
			doctor = doctorRepository.findById(doctorRequest.getId())
					.orElseThrow(() -> new HospitalManagementException("Doctor Not Found# " + doctorRequest.getId()));
		}
		doctor.setName(doctorRequest.getName());
		doctor.setSpecialization(doctorRequest.getSpecialization());
		if (doctorRequest.getDepartmentId() != null) {
			doctor.setDepartment(departmentService.findOptionalDepartmentById(doctorRequest.getDepartmentId())
					.orElseThrow(() -> new HospitalManagementException(
							"Department Not Found# " + doctorRequest.getDepartmentId())));
		}
		if (!CommonUtil.isEmpty(doctorRequest.getShiftIds())) {
			List<Shift> shifts = shiftService.findAllById(doctorRequest.getShiftIds());
			if (shifts.size() != doctorRequest.getShiftIds().size()) {
				throw new IllegalArgumentException("One or more shifts not found");
			}
			doctor.setShifts(new HashSet<>(shifts));
		}
		doctorRepository.save(doctor);
		return doctorHelper.getDoctorResponse(doctor);
	}

	@Override
	public DoctorResponse findById(Long id) throws HospitalManagementException {
		Doctor existingDoctor = doctorRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Doctor Not Found# " + id));
		return doctorHelper.getDoctorResponse(existingDoctor);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		Doctor existingDoctor = doctorRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Doctor Not Found# " + id));
		doctorRepository.deleteById(existingDoctor.getId());
	}

	@Override
	public void addShiftToDoctor(Long id, Long shiftId) throws HospitalManagementException {
		Doctor existingDoctor = doctorRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Doctor Not Found# " + id));
		Shift shift = shiftService.findOptionalById(shiftId)
				.orElseThrow(() -> new HospitalManagementException("Shift Not Found# " + id));
		existingDoctor.getShifts().add(shift);
        doctorRepository.save(existingDoctor);
	}

	@Override
	public void removeShiftFromDoctor(Long id, Long shiftId) throws HospitalManagementException {
		Doctor existingDoctor = doctorRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Doctor Not Found# " + id));
		Shift shift = shiftService.findOptionalById(shiftId)
				.orElseThrow(() -> new HospitalManagementException("Shift Not Found# " + id));
		if (!CommonUtil.isEmpty(existingDoctor.getShifts())) {
			existingDoctor.getShifts().remove(shift);
		}		
		doctorRepository.save(existingDoctor);
	}

	@Override
	public Set<Doctor> findAllById(Set<Long> ids) {
		return doctorRepository.findByIdIn(ids);
	}

}
