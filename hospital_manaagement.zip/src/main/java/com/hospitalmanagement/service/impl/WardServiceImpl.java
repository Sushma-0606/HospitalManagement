package com.hospitalmanagement.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Ward;
import com.hospitalmanagement.helper.WardHelper;
import com.hospitalmanagement.repository.WardRepository;
import com.hospitalmanagement.request.WardRequest;
import com.hospitalmanagement.response.WardResponse;
import com.hospitalmanagement.service.WardService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class WardServiceImpl implements WardService {

	@Autowired
	WardRepository wardRepository;
	@Autowired
	WardHelper wardHelper;

	@Override
	public Optional<Ward> findOptionalById(Long id) {
		return wardRepository.findById(id);
	}

	@Override
	public List<WardResponse> findAll() {
		return wardRepository.findAll().stream().map(wardHelper::getWardResponse).toList();
	}

	@Override
	public WardResponse findById(Long id) throws HospitalManagementException {
		Ward ward = wardRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Ward Not Found# " + id));
		return wardHelper.getWardResponse(ward);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		Ward ward = wardRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Ward Not Found# " + id));
		wardRepository.deleteById(ward.getId());
	}

	@Override
	public WardResponse save(WardRequest wardRequest) throws HospitalManagementException {
		Ward ward = new Ward();
		if (wardRequest.getId() != null) {
			ward = wardRepository.findById(wardRequest.getId())
					.orElseThrow(() -> new HospitalManagementException("Ward Not Found# " + wardRequest.getId()));
		}
		ward.setDescription(wardRequest.getDescription());
		ward.setName(wardRequest.getName());
		wardRepository.save(ward);
		return wardHelper.getWardResponse(ward);
	}
}
