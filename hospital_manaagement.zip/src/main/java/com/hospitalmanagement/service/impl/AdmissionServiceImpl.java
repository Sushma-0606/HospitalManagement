package com.hospitalmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.entity.Admission;
import com.hospitalmanagement.entity.Patient;
import com.hospitalmanagement.entity.Ward;
import com.hospitalmanagement.helper.AdmissionHelper;
import com.hospitalmanagement.repository.AdmissionRepository;
import com.hospitalmanagement.request.AdmissionRequest;
import com.hospitalmanagement.response.AdmissionResponse;
import com.hospitalmanagement.service.AdmissionService;
import com.hospitalmanagement.service.PatientService;
import com.hospitalmanagement.service.WardService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AdmissionServiceImpl implements AdmissionService {

	@Autowired AdmissionRepository admissionRepository;
	@Autowired PatientService patientService;
	@Autowired WardService wardService;
	@Autowired AdmissionHelper admissionHelper;

	@Override
	public List<Admission> findAll() {
		return admissionRepository.findAll();
	}

	@Override
	public AdmissionResponse save(AdmissionRequest admissionRequest) {
		Admission admission;
		if (admissionRequest.getId() != null) {
			admission = admissionRepository.findById(admissionRequest.getId())
					.orElseThrow(() -> new RuntimeException("Admission Not Found# " + admissionRequest.getId()));
		} else {
			admission = new Admission();
		}
		admission.setAdmissionDateTime(admissionRequest.getAdmissionDateTime());
		admission.setDischargeDateTime(admissionRequest.getDischargeDateTime());
		
		if (admissionRequest.getPatientId() != null) {
			Patient patient = patientService.findOptionalById(admissionRequest.getPatientId()).orElseThrow(
					() -> new RuntimeException("Patient not found with id: " + admissionRequest.getPatientId()));
			admission.setPatient(patient);
		}

		if (admission.getWard() != null) {
			Ward ward = wardService.findOptionalById(admissionRequest.getWardId())
					.orElseThrow(() -> new RuntimeException("Ward not found with id: " + admission.getWard()));
			admission.setWard(ward);
		}
		admissionRepository.save(admission);
		return admissionHelper.getAdmissionResponse(admission);
	}

	@Override
	public AdmissionResponse findById(Long id) {
		Admission existingAdmission = admissionRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Admission Not Found# " + id));
		return admissionHelper.getAdmissionResponse(existingAdmission);
	}

	@Override
	public void deleteById(Long id) {
		Admission existingAdmission = admissionRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Admission Not Found# " + id));
		admissionRepository.deleteById(existingAdmission.getId());
	}
}
