package com.hospitalmanagement.service.impl;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Shift;
import com.hospitalmanagement.entity.Staff;
import com.hospitalmanagement.helper.StaffHelper;
import com.hospitalmanagement.repository.StaffRepository;
import com.hospitalmanagement.request.StaffRequest;
import com.hospitalmanagement.response.StaffResponse;
import com.hospitalmanagement.service.DepartmentService;
import com.hospitalmanagement.service.ShiftService;
import com.hospitalmanagement.service.StaffService;
import com.hospitalmanagement.util.CommonUtil;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class StaffServiceImpl implements StaffService {

	@Autowired
	StaffRepository staffRepository;
	@Autowired
	StaffHelper staffHelper;

	@Autowired
	DepartmentService departmentService;
	@Autowired
	ShiftService shiftService;

	@Override
	public Set<Staff> findAllById(Set<Long> ids) {
		return staffRepository.findByidIn(ids);
	}

	@Override
	public List<StaffResponse> findAll() {
		return staffRepository.findAll().stream().map(staffHelper::getStaffResponse).toList();
	}

	@Override
	public StaffResponse findById(Long id) throws HospitalManagementException {
		Staff staff = staffRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Staff Not Found# " + id));
		return staffHelper.getStaffResponse(staff);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		Staff staff = staffRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Staff Not Found# " + id));
		staffRepository.deleteById(staff.getId());
	}

	@Override
	public StaffResponse save(StaffRequest staffRequest) throws HospitalManagementException {
		Staff staff = new Staff();
		if (staffRequest.getId() != null) {
			staff = staffRepository.findById(staffRequest.getId())
					.orElseThrow(() -> new HospitalManagementException("Staff Not Found# " + staffRequest.getId()));
		}
		staff.setAddress(staffRequest.getAddress());
		staff.setName(staffRequest.getName());
		staff.setRole(staffRequest.getRole());
		staffRepository.save(staff);
		if (staffRequest.getDepartmentId() != null) {
			staff.setDepartment(departmentService.findOptionalDepartmentById(staffRequest.getDepartmentId())
					.orElseThrow(() -> new HospitalManagementException(
							"Department Not Found# " + staffRequest.getDepartmentId())));
		}
		if (!CommonUtil.isEmpty(staffRequest.getShiftIds())) {
			Set<Shift> shifts = new HashSet<>(shiftService.findAllById(staffRequest.getShiftIds()));
			staff.setShifts(shifts);
		}
		staffRepository.save(staff);
		return staffHelper.getStaffResponse(staff);
	}
}
