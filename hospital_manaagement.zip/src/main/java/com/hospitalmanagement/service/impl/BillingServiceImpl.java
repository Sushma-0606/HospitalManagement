package com.hospitalmanagement.service.impl;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Billing;
import com.hospitalmanagement.helper.BillingHelper;
import com.hospitalmanagement.repository.BillingRepository;
import com.hospitalmanagement.request.BillingRequest;
import com.hospitalmanagement.response.BillingResponse;
import com.hospitalmanagement.service.AppointmentService;
import com.hospitalmanagement.service.BillingService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class BillingServiceImpl implements BillingService {

	@Autowired
	BillingRepository billingRepository;
	@Autowired
	BillingHelper billingHelper;
	@Autowired
	AppointmentService appointmentService;

	@Override
	public List<BillingResponse> findAll() {
		return billingRepository.findAll().stream().map(billingHelper::getBillingResponse).toList();
	}

	@Override
	public BillingResponse createOrUpdate(BillingRequest billingRequest) throws HospitalManagementException {
		Billing billing;
		if (billingRequest.getId() != null) {
			billing = billingRepository.findById(billingRequest.getId())
					.orElseThrow(() -> new RuntimeException("Billing Not Found# " + billingRequest.getId()));
		} else {
			billing = new Billing();
		}
		validateBillingRequest(billingRequest);
		billing.setAppointment(appointmentService.findOptionalById(billingRequest.getAppointmentId()).orElseThrow(
				() -> new HospitalManagementException("Appointment Not Found# " + billingRequest.getAppointmentId())));
		billing.setTotalAmount(billingRequest.getTotalAmount());
		billingRepository.save(billing);
		return billingHelper.getBillingResponse(billing);
	}

	private void validateBillingRequest(BillingRequest billingRequest) throws HospitalManagementException {
		if (billingRequest.getAppointmentId() == null)
			throw new HospitalManagementException("Appointment Id should be provided");
		if (billingRequest.getTotalAmount() == null || billingRequest.getTotalAmount().compareTo(BigDecimal.ZERO) <= 0)
			throw new HospitalManagementException("Total Amount should be greater than Zero");
	}

	@Override
	public BillingResponse findById(Long id) {
		Billing existingBilling = billingRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Billing Not Found# " + id));
		return billingHelper.getBillingResponse(existingBilling);
	}

	@Override
	public void deleteById(Long id) {
		Billing existingBilling = billingRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Billing Not Found# " + id));
		billingRepository.delete(existingBilling);
	}

	@Override
	public Billing findByIdWithException(Long id) throws HospitalManagementException {
		return billingRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Billing Not Found# " + id));
	}

}
