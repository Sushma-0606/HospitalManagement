package com.hospitalmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Test;
import com.hospitalmanagement.helper.TestHelper;
import com.hospitalmanagement.repository.TestRepository;
import com.hospitalmanagement.request.TestRequest;
import com.hospitalmanagement.response.TestResponse;
import com.hospitalmanagement.service.TestService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class TestServiceImpl implements TestService {

	@Autowired
	TestRepository testRepository;
	@Autowired
	TestHelper testHelper;
	
	@Override
	public TestResponse save(TestRequest testRequest) throws HospitalManagementException {
		Test test = new Test();
		if (testRequest.getId() != null) {
			test = testRepository.findById(testRequest.getId())
					.orElseThrow(() -> new HospitalManagementException("Test Not Found" + testRequest.getId()));
		}
		test.setDescription(testRequest.getDescription());
		test.setName(testRequest.getName());
		testRepository.save(test);
		return testHelper.getTestResponse(test);
	}

	@Override
	public List<TestResponse> findAll() {
		return testRepository.findAll().stream().map(testHelper::getTestResponse).toList();
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		Test test = testRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Test Not Found" + id));
		testRepository.deleteById(test.getId());
	}

	@Override
	public TestResponse findById(Long id) throws HospitalManagementException {
		Test test = testRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Test Not Found" + id));
		return testHelper.getTestResponse(test);
	}

	@Override
	public Test findByIdWithException(Long id) throws HospitalManagementException {
		return testRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Test Not Found" + id));
	}

}
