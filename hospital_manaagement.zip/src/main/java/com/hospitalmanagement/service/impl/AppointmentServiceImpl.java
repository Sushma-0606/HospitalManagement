package com.hospitalmanagement.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Appointment;
import com.hospitalmanagement.helper.AppointmentHelper;
import com.hospitalmanagement.repository.AppointmentRepository;
import com.hospitalmanagement.request.AppointmentRequest;
import com.hospitalmanagement.response.AppointmentResponse;
import com.hospitalmanagement.service.AppointmentService;
import com.hospitalmanagement.service.DoctorService;
import com.hospitalmanagement.service.PatientService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class AppointmentServiceImpl implements AppointmentService {

	@Autowired
	AppointmentRepository appointmentRepository;
	@Autowired
	@Lazy
	DoctorService doctorService;
	@Lazy
	@Autowired
	PatientService patientService;
	@Autowired
	AppointmentHelper appointmentHelper;

	@Override
	public List<AppointmentResponse> findAll() {
		return appointmentRepository.findAll().stream().map(appointmentHelper::getAppointmentResponse).toList();
	}

	@Override
	public AppointmentResponse save(AppointmentRequest appointmentRequest) throws HospitalManagementException {
		Appointment appointment;
		if (appointmentRequest.getId() != null) {
			appointment = appointmentRepository.findById(appointmentRequest.getId())
					.orElseThrow(() -> new RuntimeException("Admission Not Found# " + appointmentRequest.getId()));
		} else {
			appointment = new Appointment();
		}
		validateRequest(appointmentRequest);
		appointment.setDoctor(doctorService.findOptionalById(appointmentRequest.getDoctorId()).orElseThrow(
				() -> new HospitalManagementException("Doctor not Found# " + appointmentRequest.getDoctorId())));
		appointment.setPatient(patientService.findOptionalById(appointmentRequest.getPatientId()).orElseThrow(
				() -> new HospitalManagementException("Patient not Found# " + appointmentRequest.getPatientId())));
		appointmentRepository.save(appointment);
		return appointmentHelper.getAppointmentResponse(appointment);
	}

	private void validateRequest(AppointmentRequest appointmentRequest) throws HospitalManagementException {
		if (appointmentRequest.getDoctorId() == null || appointmentRequest.getPatientId() == null)
			throw new HospitalManagementException("Both Doctor Id and Patient Id must be provided.");
	}

	@Override
	public AppointmentResponse findById(Long id) {
		Appointment existingAppointment = appointmentRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Admission Not Found# " + id));
		return appointmentHelper.getAppointmentResponse(existingAppointment);
	}

	@Override
	public void deleteById(Long id) {
		Appointment existingAppointment = appointmentRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Admission Not Found# " + id));
		appointmentRepository.delete(existingAppointment);
	}

	@Override
	public Optional<Appointment> findOptionalById(Long id) {
		return appointmentRepository.findById(id);
	}

	@Override
	public Appointment findByIdWithException(Long id) {
		return appointmentRepository.findById(id)
				.orElseThrow(() -> new RuntimeException("Admission Not Found# " + id));
	}
}
