package com.hospitalmanagement.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Prescription;
import com.hospitalmanagement.helper.PrescriptionHelper;
import com.hospitalmanagement.repository.PrescriptionRepository;
import com.hospitalmanagement.request.PrescriptionRequest;
import com.hospitalmanagement.response.PrescriptionResponse;
import com.hospitalmanagement.service.AppointmentService;
import com.hospitalmanagement.service.DoctorService;
import com.hospitalmanagement.service.PatientService;
import com.hospitalmanagement.service.PrescriptionService;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@Service
@FieldDefaults(level = AccessLevel.PRIVATE)
public class PrescriptionServiceImpl implements PrescriptionService {

	@Autowired
	PrescriptionRepository prescriptionRepository;
	@Autowired
	PrescriptionHelper prescriptionHelper;
	@Autowired
	AppointmentService appointmentService;
	@Autowired
	DoctorService doctorService;
	@Autowired
	PatientService patientService;

	@Override
	public List<PrescriptionResponse> findAll() {
		return prescriptionRepository.findAll().stream().map(prescriptionHelper::getPrescriptionResponse).toList();
	}

	@Override
	public PrescriptionResponse findById(Long id) throws HospitalManagementException {
		Prescription prescription = prescriptionRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Prescription Not Found# " + id));
		return prescriptionHelper.getPrescriptionResponse(prescription);
	}

	@Override
	public void deleteById(Long id) throws HospitalManagementException {
		Prescription prescription = prescriptionRepository.findById(id)
				.orElseThrow(() -> new HospitalManagementException("Prescription Not Found# " + id));
		prescriptionRepository.deleteById(prescription.getId());
	}

	@Override
	public PrescriptionResponse save(PrescriptionRequest prescriptionRequest) throws HospitalManagementException {
		Prescription prescription = new Prescription();
		if (prescriptionRequest.getId() != null) {
			prescription = prescriptionRepository.findById(prescriptionRequest.getId()).orElseThrow(
					() -> new HospitalManagementException("Prescription Not Found# " + prescriptionRequest.getId()));
		}
		prescription.setPrescriptionText(prescriptionRequest.getPrescriptionText());
		if (prescriptionRequest.getAppointmentId() != null) {
			prescription.setAppointment(appointmentService.findOptionalById(prescriptionRequest.getAppointmentId())
					.orElseThrow(() -> new HospitalManagementException(
							"Appointment Not Found# " + prescriptionRequest.getAppointmentId())));
		}
		if (prescriptionRequest.getDoctorId() != null) {
			prescription.setDoctor(doctorService.findOptionalById(prescriptionRequest.getDoctorId())
					.orElseThrow(() -> new HospitalManagementException(
							"Doctor Not Found# " + prescriptionRequest.getDoctorId())));
		}
		if (prescriptionRequest.getPatientId() != null) {
			prescription.setPatient(patientService.findOptionalById(prescriptionRequest.getPatientId())
					.orElseThrow(() -> new HospitalManagementException(
							"Patient Not Found# " + prescriptionRequest.getPatientId())));
		}
		prescriptionRepository.save(prescription);
		return prescriptionHelper.getPrescriptionResponse(prescription);
	}
}
