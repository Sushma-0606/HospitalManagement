package com.hospitalmanagement.service;

import java.util.List;
import java.util.Optional;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Department;
import com.hospitalmanagement.request.DepartmentRequest;
import com.hospitalmanagement.response.DepartmentResponse;

public interface DepartmentService {

	List<DepartmentResponse> findAll();

	DepartmentResponse findById(Long id) throws HospitalManagementException;

	DepartmentResponse save(DepartmentRequest departmentRequest) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;
	
	Optional<Department> findOptionalDepartmentById(Long id);

}
