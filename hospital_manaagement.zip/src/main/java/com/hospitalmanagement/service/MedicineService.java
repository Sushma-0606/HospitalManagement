package com.hospitalmanagement.service;

import java.util.List;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.request.MedicineRequest;
import com.hospitalmanagement.response.MedicineResposne;

public interface MedicineService {

	List<MedicineResposne> findAll();

	MedicineResposne save(MedicineRequest medicineRequest) throws HospitalManagementException;

	MedicineResposne findById(Long id) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;

}
