package com.hospitalmanagement.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Shift;
import com.hospitalmanagement.request.ShiftRequest;
import com.hospitalmanagement.response.ShiftResponse;

public interface ShiftService {

	List<Shift> findAllById(Set<Long> ids);

	Optional<Shift> findOptionalById(Long id);

	List<ShiftResponse> findAll();

	ShiftResponse findById(Long id) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;

	ShiftResponse save(ShiftRequest shiftRequest) throws HospitalManagementException;

}
