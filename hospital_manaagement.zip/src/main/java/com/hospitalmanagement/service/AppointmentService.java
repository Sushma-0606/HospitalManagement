package com.hospitalmanagement.service;

import java.util.List;
import java.util.Optional;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Appointment;
import com.hospitalmanagement.request.AppointmentRequest;
import com.hospitalmanagement.response.AppointmentResponse;

public interface AppointmentService {

	List<AppointmentResponse> findAll();

	AppointmentResponse save(AppointmentRequest appointmentRequest) throws HospitalManagementException;

	AppointmentResponse findById(Long id);

	void deleteById(Long id);
	
	Optional<Appointment> findOptionalById(Long id);

	Appointment findByIdWithException(Long id);

}
