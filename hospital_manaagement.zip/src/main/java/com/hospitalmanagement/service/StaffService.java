package com.hospitalmanagement.service;

import java.util.List;
import java.util.Set;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Staff;
import com.hospitalmanagement.request.StaffRequest;
import com.hospitalmanagement.response.StaffResponse;

public interface StaffService {

	Set<Staff> findAllById(Set<Long> ids);

	List<StaffResponse> findAll();

	StaffResponse findById(Long id) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;

	StaffResponse save(StaffRequest staffRequest) throws HospitalManagementException;

}
