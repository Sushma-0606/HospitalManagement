package com.hospitalmanagement.service;

import java.util.List;
import java.util.Optional;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Ward;
import com.hospitalmanagement.request.WardRequest;
import com.hospitalmanagement.response.WardResponse;

public interface WardService {

	Optional<Ward> findOptionalById(Long id);

	List<WardResponse> findAll();

	WardResponse findById(Long id) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;

	WardResponse save(WardRequest wardRequest) throws HospitalManagementException;

}
