package com.hospitalmanagement.service;

import java.util.List;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.request.UserRequest;
import com.hospitalmanagement.response.UserResponse;

public interface UserService {

	List<UserResponse> findAll();

	UserResponse findById(Long id) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;

	UserResponse save(UserRequest userRequest) throws HospitalManagementException;

}
