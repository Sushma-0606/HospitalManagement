package com.hospitalmanagement.service;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Doctor;
import com.hospitalmanagement.request.DoctorRequest;
import com.hospitalmanagement.response.DoctorResponse;

public interface DoctorService {

	Optional<Doctor> findOptionalById(Long id);

	List<DoctorResponse> findAll();

	DoctorResponse save(DoctorRequest doctorRequest) throws HospitalManagementException;

	DoctorResponse findById(Long id) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;

	void addShiftToDoctor(Long id, Long shiftId) throws HospitalManagementException;

	void removeShiftFromDoctor(Long id, Long shiftId) throws HospitalManagementException;

	Set<Doctor> findAllById(Set<Long> ids);

}
