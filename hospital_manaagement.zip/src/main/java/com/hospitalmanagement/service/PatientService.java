package com.hospitalmanagement.service;

import java.util.List;
import java.util.Optional;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Patient;
import com.hospitalmanagement.request.PatientRequest;
import com.hospitalmanagement.response.PatientResponse;

public interface PatientService {

	Optional<Patient> findOptionalById(Long id);

	List<PatientResponse> findAll();

	PatientResponse findById(Long id) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;

	PatientResponse save(PatientRequest patientRequest) throws HospitalManagementException;

}
