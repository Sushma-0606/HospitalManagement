package com.hospitalmanagement.service;

import java.util.List;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.entity.Test;
import com.hospitalmanagement.request.TestRequest;
import com.hospitalmanagement.response.TestResponse;

public interface TestService {

	List<TestResponse> findAll();

	void deleteById(Long id) throws HospitalManagementException;

	TestResponse findById(Long id) throws HospitalManagementException;

	TestResponse save(TestRequest testRequest) throws HospitalManagementException;

	Test findByIdWithException(Long testId) throws HospitalManagementException;

}
