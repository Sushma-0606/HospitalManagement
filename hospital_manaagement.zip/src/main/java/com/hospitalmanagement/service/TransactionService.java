package com.hospitalmanagement.service;

import java.util.List;

import com.hospitalmanagement.HospitalManagementException;
import com.hospitalmanagement.request.TransactionRequest;
import com.hospitalmanagement.response.TransactionResponse;

public interface TransactionService {

	List<TransactionResponse> findAll();

	TransactionResponse findById(Long id) throws HospitalManagementException;

	void deleteById(Long id) throws HospitalManagementException;

	TransactionResponse save(TransactionRequest transactionRequest) throws HospitalManagementException;

}
