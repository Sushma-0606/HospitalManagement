package com.hospitalmanagement.util;


import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.apache.tomcat.util.json.JSONParser;
import org.springframework.util.ObjectUtils;


import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.experimental.FieldDefaults;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE)
public class CommonUtil {

	public static boolean isStringEmpty(Object object) {
		try {
			boolean isEmpty = false;
			if (object == null || ((String) object).trim().length() == 0) {
				isEmpty = true;
			}
			return isEmpty;
		} catch (NullPointerException e) {
			return true;
		}
	}

//	public static boolean isEmpty(String string) {
//		return StringUtils.isBlank(string);
//	}

	public static boolean isEmpty(Object string) {
		return ObjectUtils.isEmpty(string);
	}

	public static boolean isValid(Long value) {
		return value != null && value > 0;
	}

	public static boolean isValid(Integer value) {
		return value != null && value > 0;
	}

	public static boolean isTrue(Boolean value) {
		return value != null && value;
	}

	public static boolean isValid(BigDecimal value) {
		return value != null && value.intValue() > 0;
	}

	public static boolean isValid(Double value) {
		return value != null && value > 0;
	}

	public static boolean isValid(String value) {
		return value != null && !value.isEmpty();
	}

	public static boolean isListEmpty(List<?> list) {
		boolean isEmpty = false;
		if (list == null || list.isEmpty()) {
			isEmpty = true;
		}
		return isEmpty;
	}

	/**
	 * URL encode String
	 *
	 * @param String url
	 * @return encoded string
	 * @throws UnsupportedEncodingException
	 */
	public static String encodeUrl(String url) {
		try {
			return URLEncoder.encode(url, Charset.defaultCharset().toString());
		} catch (UnsupportedEncodingException e) {
			Logger.getLogger(e.getMessage());
		}
		return url;
	}

	/**
	 * URL decode String
	 *
	 * @param String encodedUrl
	 * @return decoded string
	 * @throws UnsupportedEncodingException
	 */
	public static String decodeUrl(String encodedUrl) {
		try {
			return URLDecoder.decode(encodedUrl, Charset.defaultCharset().toString());
		} catch (UnsupportedEncodingException e) {
			Logger.getLogger(e.getMessage());
		}
		return encodedUrl;
	}

	public static Boolean getIsDateExpired(Date validUptoDate2) {
		Date currentDate = new Date();
		long diff = DateUtil.diff(currentDate, validUptoDate2);
		if (diff > 0) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}

	public static String getEnvVariableByName(String name) {
		Map<String, String> env = System.getenv();
		return env.get(name);
	}

	public static String generateRandomPassword() {
		// ASCII range - alphanumeric (0-9, a-z, A-Z)
		final String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
		SecureRandom random = new SecureRandom();
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < 6; i++) {
			int randomIndex = random.nextInt(chars.length());
			sb.append(chars.charAt(randomIndex));
		}
		return sb.toString();
	}

//	public static Long getCurrentUserId() {
//		try {
//			CustomUserDetail customUserDetail = (CustomUserDetail) SecurityContextHolder.getContext()
//					.getAuthentication().getPrincipal();
//			return customUserDetail.getId();
//		} catch (Exception e) {
//			Logger.getLogger(e.getMessage());
//			throw e;
//		}
//	}

	public static Object convertStringToJsonObject(Object string) {
		try {
			if (string instanceof String && !isStringEmpty(string) && !"null".equals(string)) {
				JSONParser parser = new JSONParser(string.toString());
				return parser.parse();
			}
		} catch (Exception e) {
			Logger.getLogger(e.getMessage());
		}
		return null;
	}

	public static BigDecimal getAmount(Double percentage, BigDecimal amount) {
		BigDecimal percentageAmount = BigDecimal.valueOf(percentage);
		percentageAmount = percentageAmount.divide(new BigDecimal(100));
		return amount.multiply(percentageAmount);

	}

	public static String formatAmount(BigDecimal amount) {
		if (amount != null) {
			return rupeeFormat(String.valueOf(amount.doubleValue()));
		}
		return "";
	}

	public static String rupeeFormat(String value) {
		value = value.replace(",", "");
		String fractionValue = "";
		if (value.indexOf(".") > BigDecimal.ZERO.longValue()) {
			fractionValue = value.substring(value.indexOf(".") + 1);
			BigDecimal fractionIntValue = new BigDecimal(fractionValue);
			if (BigDecimal.ZERO.equals(fractionIntValue)) {
				fractionValue = "";
			}
			value = value.substring(0, value.indexOf("."));
		}
		Character lastDigit = value.charAt(value.length() - 1);
		int len = value.length() - 1;
		int nDigits = 0;
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = len - 1; i >= 0; i--) {

			Character charAt = value.charAt(i);
			stringBuilder = new StringBuilder(charAt.toString()).append(stringBuilder);
			nDigits++;
			if (((nDigits % 2) == 0) && (i > 0)) {
				stringBuilder = new StringBuilder(",").append(stringBuilder);
			}
		}
		if (!fractionValue.isEmpty()) {
			return stringBuilder.append(lastDigit.toString()).append(".").append(fractionValue).toString();
		}
		return stringBuilder.append(lastDigit.toString()).toString();
	}

//	@SuppressWarnings("rawtypes")
//	public static List<String> getCapitalizeFullyList(Enum... enums) {
//		List<String> list = new ArrayList<>();
//		for (Enum enumString : enums) {
//			list.add(getCapitalizeFully(enumString.toString()));
//		}
//		return list;
//	}

//	public static String getCapitalizeFully(String string) {
//		return WordUtils.capitalizeFully(string.replace("_", " "));
//	}

	public static String generateRandomDigit(Integer digit) throws NoSuchAlgorithmException {
		StringBuilder builder = new StringBuilder();
		String no = "4";
		if (null != digit) {
			no = digit.toString();
		}
		return String.format(builder.append("%0").append(no).append("d").toString(), getRandom(10000));
	}

	public static List<String> longToString(List<Long> longs) {
		if (!isListEmpty(longs)) {
			return longs.stream().map(Object::toString).collect(Collectors.toList());
		}
		return new ArrayList<>();
	}

	public static String getStaticFieldName(String displayNameStartsWith, String name) {
		if (isEmpty(displayNameStartsWith)) {
			return name;
		}
		return displayNameStartsWith + " " + name;
	}

	public static Object cast(String classSimpleName, Object value, Boolean isDisplay) {
		if (null == value) {
			return null;
		} else if (Long.class.getSimpleName().equals(classSimpleName)) {
			return Long.parseLong(value.toString());
		} else if (String.class.getSimpleName().equals(classSimpleName)) {
			return value.toString();
		} else if (Integer.class.getSimpleName().equals(classSimpleName)) {
			return Integer.parseInt(value.toString());
		} else if (Double.class.getSimpleName().equals(classSimpleName)) {
			return Double.parseDouble(value.toString());
		} else if (Boolean.class.getSimpleName().equals(classSimpleName)) {
			return Boolean.parseBoolean(value.toString());
		} else if (Date.class.getSimpleName().equals(classSimpleName)) {
			if (Boolean.TRUE.equals(isDisplay)) {
				return DateUtil.getDefaultDateTime((Date) value);
			}
			return value;
		}
		return value;
	}

	public static List<String> convertStringArrayToList(String[] strings) {
		List<String> list = new ArrayList<>();
		for (String string : strings) {
			Arrays.asList(list.add(string));
		}
		return list;
	}

	public static boolean isEmpty(Collection<?> list) {
		return list == null || list.isEmpty();
	}

	public static BigDecimal getBigDecimal(Double value) {
		return value != null ? BigDecimal.valueOf(value) : null;
	}
	
	public static int getRandom(int value) throws NoSuchAlgorithmException {
		return SecureRandom.getInstanceStrong().nextInt(value);  
	}

	public static Long getLong(Object object) {
		return object != null ? Long.parseLong(object.toString()) : null;
	}
	
	public static String getString(Object object) {
		return object != null ? object.toString() : null;
	}
	
	public static Double getDouble(Object object) {
		return object != null ? Double.parseDouble(object.toString()) : null;
	}

	public static Integer getInteger(Object object) {
		return object != null ? Integer.parseInt(object.toString()) : null;
	}
	
	public static Double getFormattedDouble(Object object) {
		if (object == null)
			return null;
		DecimalFormat format = new DecimalFormat("0.00"); 
		format.setRoundingMode(RoundingMode.DOWN);
		return getDouble(format.format(Double.parseDouble(object.toString())));
	}

	public static Date getDate(Object object) {
		return object != null ? (Date) object : null;
	}
	
	public static Long getZeroIfNull(Long originalQantity) {
		if (originalQantity == null)
			return Long.valueOf(0);
		return originalQantity;
	}

	public static Long getPositiveNumber(Long number) {
		if (number == null)
			return null;
		return Math.abs(number);
	}
	
	public static String getLowecase(String word) {
		if (word == null)
			return null;
		return word.toLowerCase();
	}
	
	public static Long getLongRemovedAfterDot(Object object) {
		return object != null ? Long.parseLong(object.toString().replaceAll("\\.\\d+", "")) : null;
	}
	
	public static BigDecimal getBigDecimal(Object object) {
	    if (object != null) {
	        try {
	            return new BigDecimal(object.toString());
	        } catch (NumberFormatException e) {
	            return null; 
	        }
	    }
	    return null;
	}
}

