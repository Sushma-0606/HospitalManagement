package com.hospitalmanagement.util;

import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;

//import com.vetplus.model.DateModel;

public class DateUtil {

	private static final Logger LOGGER = LogManager.getLogger(DateUtil.class);

	private DateUtil() {
		super();
	}

	public static final String SIMPLE_DATE_FORMATE = "yyyy-MM-dd HH:mm:ss a";
	public static final String EXPORT_FORMAT = "dd/MM/yyyy";
	public static final String FILE_FORMAT = "yyyy-MM-dd";

	/**
	 * Description - Method to Get Today's day
	 *
	 * @param dayFormat
	 * @param timeZone
	 * @return
	 */
	public static String getTodaysDay(String dayFormat, TimeZone timeZone) {
		Date date = new Date();
		/* Specifying the format */
		DateFormat requiredFormat = new SimpleDateFormat(dayFormat);
		/* Setting the Timezone */
		requiredFormat.setTimeZone(timeZone);
		/* Picking the day value in the required Format */
		return requiredFormat.format(date).toUpperCase();
	}

	/**
	 * Description - Method to Get Current time
	 *
	 * @param timeFormat
	 * @param timeZone
	 * @return
	 */
	public static String getCurrentTime(String timeFormat, TimeZone timeZone) {
		/* Specifying the format */
		DateFormat dateFormat = new SimpleDateFormat(timeFormat);
		/* Setting the Timezone */
		Calendar cal = Calendar.getInstance(timeZone);
		dateFormat.setTimeZone(cal.getTimeZone());
		/* Picking the time value in the required Format */
		return dateFormat.format(cal.getTime());
	}

	/**
	 * Description - Method to Get Today's date
	 *
	 * @param dateFormat
	 * @param timeZone
	 * @return
	 */
	public static String getTodayDate(String dateFormat, TimeZone timeZone) {
		Date todayDate = new Date();
		/* Specifying the format */
		DateFormat todayDateFormat = new SimpleDateFormat(dateFormat);
		/* Setting the Timezone */
		todayDateFormat.setTimeZone(timeZone);
		/* Picking the date value in the required Format */
		return todayDateFormat.format(todayDate);
	}

	public static Date getDateChangedByMinutes(int minutes, TimeZone timeZone) {
		Calendar calendar = Calendar.getInstance(timeZone);
		calendar.add(Calendar.MINUTE, minutes);
		return calendar.getTime();
	}

	public static List<String> getYearList() {
		List<String> yearList = new ArrayList<>();
		for (int year = 2000; year <= 2100; year++) {
			yearList.add(String.valueOf(year));
		}
		return yearList;
	}

	public static List<String> getMonthList() {
		List<String> monthList = new ArrayList<>();
		String[] months = new DateFormatSymbols().getMonths();
		for (int i = 0; i < months.length; i++) {
			String month = months[i];
			if (!month.trim().isEmpty()) {
				monthList.add(months[i]);
			}
		}
		return monthList;
	}

	public static TimeZone getTimeZone(String timezoneId) {
		if (timezoneId == null) {
			timezoneId = "UTC";
		}
		return TimeZone.getTimeZone(timezoneId);
	}

	public static Date getUTCDateFRomUserTimezoneDate(Date date, TimeZone userTimeZone) {
		return new Date(date.getTime() - userTimeZone.getOffset(date.getTime()));
	}

	public static Date getUserTimezoneDateFromUTC(Date date, TimeZone userTimeZone) {
		return new Date(date.getTime() + userTimeZone.getOffset(date.getTime()));
	}

	public static Date getDateFromString(String date) {
		try {
			return new SimpleDateFormat(SIMPLE_DATE_FORMATE).parse(date);
		} catch (ParseException ex) {
			LOGGER.log(Level.ERROR, ex);
		}
		return null;
	}

	public static Date getDateByLongString(String date) {
		return new Date(Long.parseLong(date));
	}

	public static String getUserTimezoneStringDateFromUTC(Date date, TimeZone userTimeZone) {
		Date date1 = new Date(date.getTime() + userTimeZone.getOffset(date.getTime()));
		return new SimpleDateFormat(SIMPLE_DATE_FORMATE).format(date1);
	}

	public static String getFormattedTimeInHoursAndMins(Date date, TimeZone userTimeZone) {
		Date date1 = new Date(date.getTime() + userTimeZone.getOffset(date.getTime()));
		SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm a", Locale.ENGLISH);
		return timeFormat.format(date1);
	}

	public static Date getThisWeekFirstDate() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 0); // ! clear would not reset the hour of day !
		cal.clear(Calendar.MINUTE);
		cal.clear(Calendar.SECOND);
		cal.clear(Calendar.MILLISECOND);
		cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
		return cal.getTime();
	}

	public static Date getThisWeekLastDate() {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.DAY_OF_WEEK, cal.getFirstDayOfWeek());
		cal.add(Calendar.DATE, 6);
		return cal.getTime();
	}

	public static Date getStartDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(date.getTime());
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return calendar.getTime();
	}

	public static Date getEndDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(date.getTime());
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		return calendar.getTime();
	}

	public static Date getEndDate(Date date, int hour) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTimeInMillis(date.getTime());
		calendar.set(Calendar.HOUR_OF_DAY, hour);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		return calendar.getTime();
	}

	public static Date getUTCDate() {
		Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
		return calendar.getTime();
	}

	public static Date convertLongToUTC(long date) {
		try {
			Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
			calendar.setTimeInMillis(date);
			return calendar.getTime();
		} catch (Exception e) {
			LOGGER.info("Cannot Conver Long To UTC");
		}
		return null;
	}

	public static int diff(Date endDate, Date startDate) {
		long diff = endDate.getTime() - startDate.getTime();
		return (int) (diff / (24 * 60 * 60 * 1000));
	}

	public static Long getDifferenceInMinutes(Long startDate, Long endDate) {
		long diff = endDate - startDate;
		return TimeUnit.MILLISECONDS.toMinutes(diff);
	}

	public static Date addDay(Date date, int count) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) + count);
		return calendar.getTime();
	}

	public static Date subtractDay(Date date, int count) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DATE, calendar.get(Calendar.DATE) - count);
		return calendar.getTime();
	}

	public static Date addMonth(Date date, int count) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + count);
		return calendar.getTime();
	}

	public static Map<Integer, String> daysMap() {
		Map<Integer, String> map = new HashMap<>();
		map.put(1, "Sunday");
		map.put(2, "Monday");
		map.put(3, "Tuesday");
		map.put(4, "Wednesday");
		map.put(5, "Thursday");
		map.put(6, "Friday");
		map.put(7, "Saturday");
		return map;
	}

	public static void applyCustomTime(Integer time, Calendar calendar) {
		if (time != null && calendar != null) {
			if (time < 24) {
				calendar.set(Calendar.HOUR_OF_DAY, time);
				calendar.set(Calendar.MINUTE, 00);
				calendar.set(Calendar.SECOND, 00);
			} else if (time == 24) {
				calendar.set(Calendar.HOUR_OF_DAY, 23);
				calendar.set(Calendar.MINUTE, 59);
				calendar.set(Calendar.SECOND, 59);
			}
		}
	}

	public static int getTimeFormat24(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int hour = calendar.get(Calendar.HOUR_OF_DAY);
		if (hour == 23 && calendar.get(Calendar.MINUTE) == 59) {
			hour = 24;
		}
		return hour;
	}

	public static int getWeekCodeFromDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int week = calendar.get(Calendar.DAY_OF_WEEK);
		if (week == 7) {
			if ((calendar.get(Calendar.DATE) >= 1 && calendar.get(Calendar.DATE) <= 7)
					|| (calendar.get(Calendar.DATE) >= 15 && calendar.get(Calendar.DATE) <= 21)) {
				week = 8;
			}
			if (calendar.get(Calendar.DATE) >= 8 && calendar.get(Calendar.DATE) >= 14
					|| (calendar.get(Calendar.DATE) >= 22 && calendar.get(Calendar.DATE) >= 31)) {
				week = 9;
			}
		}
		return week;
	}

	public static int getMonthCodeFromDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.MONTH);
	}

	public static int getDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int d = calendar.get(Calendar.DATE);
		int maxDate = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
		if (maxDate == d) {
			return 0;
		} else if (maxDate - 1 == d) {
			return -1;
		} else {
			return d;
		}
	}

	public static int getYearFromDate(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		return calendar.get(Calendar.YEAR);
	}

	public static void applyCustomDate(Integer date, Calendar calendar) {
		if (date != null && calendar != null) {
			if (date == 0) {
				calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE));
			} else if (date == -1) {
				calendar.set(Calendar.DATE, calendar.getActualMaximum(Calendar.DATE) - 1);
			} else if (date <= 28) {
				calendar.set(Calendar.DATE, date);
			}
		}
	}

	public static String getDashBoardDateFromString(Date date) {
		SimpleDateFormat dashboardDateFormat = new SimpleDateFormat("dd MMM yyyy hh:mm a");
		return dashboardDateFormat.format(date);
	}

	public static String getReportDate(Date date) {
		SimpleDateFormat dashboardDateFormat = new SimpleDateFormat("dd MMM yyyy ");
		return dashboardDateFormat.format(date);
	}

//	public static DateModel today() {
//		Calendar calendar = Calendar.getInstance();
//		DateModel todayDate = new DateModel();
//		todayDate.setStartDate(calendar.getTime());
//		todayDate.setEndDate(calendar.getTime());
//		return todayDate;
//	}
//
//	public static DateModel lastSeventDays() {
//		DateModel lastWeekDate = new DateModel();
//		Calendar startCalendar = Calendar.getInstance();
//		startCalendar.set(Calendar.DAY_OF_MONTH, startCalendar.get(Calendar.DAY_OF_MONTH) - 6);
//		lastWeekDate.setStartDate(DateUtil.getStartDate(startCalendar.getTime()));
//
//		Calendar endCalendar = Calendar.getInstance();
//		lastWeekDate.setEndDate(DateUtil.getEndDate(endCalendar.getTime()));
//		return lastWeekDate;
//	}
//
//	public static DateModel thisWeek() {
//		DateModel thisWeekDate = new DateModel();
//		thisWeekDate.setStartDate(getWeekStartDate());
//		thisWeekDate.setEndDate(getWeekEndDate());
//		return thisWeekDate;
//	}
//
//	public static DateModel thisMonth() {
//		DateModel thisMonthDate = new DateModel();
//		Calendar calendar = Calendar.getInstance();
//		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
//		calendar.set(Calendar.HOUR, 0);
//		calendar.set(Calendar.MINUTE, 0);
//		calendar.set(Calendar.SECOND, 0);
//		thisMonthDate.setStartDate(calendar.getTime());
//
//		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
//		calendar.set(Calendar.HOUR, 23);
//		calendar.set(Calendar.MINUTE, 59);
//		calendar.set(Calendar.SECOND, 59);
//		thisMonthDate.setEndDate(calendar.getTime());
//		return thisMonthDate;
//	}
//
//	public static DateModel thisYear() {
//		Calendar calendar = Calendar.getInstance();
//		DateModel thisYearDate = new DateModel();
//		calendar.set(Calendar.MONTH, Calendar.JANUARY);
//		calendar.set(Calendar.DAY_OF_MONTH, 1);
//		calendar.set(Calendar.HOUR, 0);
//		calendar.set(Calendar.MINUTE, 0);
//		calendar.set(Calendar.SECOND, 0);
//		thisYearDate.setStartDate(calendar.getTime());
//
//		calendar.set(Calendar.MONTH, Calendar.DECEMBER);
//		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DATE));
//		calendar.set(Calendar.HOUR, 23);
//		calendar.set(Calendar.MINUTE, 59);
//		calendar.set(Calendar.SECOND, 59);
//		thisYearDate.setEndDate(calendar.getTime());
//		return thisYearDate;
//	}
//
//	public static DateModel yesterday() {
//		Calendar calendar;
//		DateModel yesterdayDate = new DateModel();
//		calendar = Calendar.getInstance();
//		calendar.add(Calendar.DATE, -1);
//		yesterdayDate.setStartDate(calendar.getTime());
//		yesterdayDate.setEndDate(calendar.getTime());
//		return yesterdayDate;
//	}
//
//	public static DateModel previousWeek() {
//		DateModel previousWeekDate = new DateModel();
//		Calendar calendar = Calendar.getInstance();
//		previousWeekDate.setStartDate(firstDayOfLastWeek(calendar).getTime());
//		previousWeekDate.setEndDate(lastDayOfLastWeek(calendar).getTime());
//		return previousWeekDate;
//	}
//
//	public static DateModel previousMonth() {
//		DateModel previousMonthDate = new DateModel();
//		Calendar calendar = Calendar.getInstance();
//		calendar.add(Calendar.MONTH, -1);
//		calendar.set(Calendar.DAY_OF_MONTH, 1);
//		calendar.set(Calendar.HOUR, 0);
//		calendar.set(Calendar.MINUTE, 0);
//		calendar.set(Calendar.SECOND, 0);
//		previousMonthDate.setStartDate(calendar.getTime());
//
//		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DATE));
//		calendar.set(Calendar.HOUR, 23);
//		calendar.set(Calendar.MINUTE, 59);
//		calendar.set(Calendar.SECOND, 59);
//		previousMonthDate.setEndDate(calendar.getTime());
//		return previousMonthDate;
//	}
//
//	public static DateModel previousYear() {
//		DateModel previousYearDate = new DateModel();
//		Calendar calendar = Calendar.getInstance();
//		calendar.add(Calendar.YEAR, -1);
//		calendar.set(Calendar.MONTH, Calendar.JANUARY);
//		calendar.set(Calendar.DAY_OF_MONTH, 1);
//		calendar.set(Calendar.HOUR, 0);
//		calendar.set(Calendar.MINUTE, 0);
//		calendar.set(Calendar.SECOND, 0);
//		previousYearDate.setStartDate(calendar.getTime());
//
//		calendar.set(Calendar.MONTH, Calendar.DECEMBER);
//		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DATE));
//		calendar.set(Calendar.HOUR, 23);
//		calendar.set(Calendar.MINUTE, 59);
//		calendar.set(Calendar.SECOND, 59);
//		previousYearDate.setEndDate(calendar.getTime());
//		return previousYearDate;
//	}

	public static Date getWeekStartDate() {
		Calendar calendar = Calendar.getInstance();
		while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
			calendar.add(Calendar.DATE, -1);
		}
		return calendar.getTime();
	}

	public static Date getWeekEndDate() {
		Calendar calendar = Calendar.getInstance();
		while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
			calendar.add(Calendar.DATE, 1);
		}
		calendar.add(Calendar.DATE, -1);
		return calendar.getTime();
	}

	public static Calendar firstDayOfLastWeek(Calendar c) {
		c = (Calendar) c.clone();
		// last week
		c.add(Calendar.WEEK_OF_YEAR, -1);
		// first day
		c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek());
		return c;
	}

	public static Calendar lastDayOfLastWeek(Calendar c) {
		c = (Calendar) c.clone();
		// first day of this week
		c.set(Calendar.DAY_OF_WEEK, c.getFirstDayOfWeek());
		// last day of previous week
		c.add(Calendar.DAY_OF_MONTH, -1);
		return c;
	}

	public static String getDefaultDate(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat dashboardDateFormat = new SimpleDateFormat(EXPORT_FORMAT);
		return dashboardDateFormat.format(date);
	}

	public static String getDefaultDateFormat(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat dashboardDateFormat = new SimpleDateFormat(FILE_FORMAT);
		return dashboardDateFormat.format(date);// MMMMM yyyy
	}

	public static String getDefaultDateFormatMonthInChars(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat dashboardDateFormat = new SimpleDateFormat("dd MMMMM yyyy");
		return dashboardDateFormat.format(date);
	}

	public static String getDefaultDateTime(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat dashboardDateFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
		return dashboardDateFormat.format(date);
	}

	public static String getDefaultDateTime24hr(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat dashboardDateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");
		return dashboardDateFormat.format(date);
	}

	public static String getWeekDayName(int weekDay) {
		String[] strDays = new String[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday",
				"Even Saturday", "Odd Saturday" };
		return strDays[weekDay];
	}

	public static Integer getUnixTime(Date date) {
		Long ut3 = date.getTime() / 1000L;
		return Integer.parseInt(ut3.toString());
	}

//	public static DateModel thisFinancialYear() {
//		Calendar calendar = Calendar.getInstance();
//		int year = calendar.get(Calendar.YEAR);
//		DateModel thisYearDate = new DateModel();
//		calendar.set(Calendar.YEAR, year);
//		calendar.set(Calendar.MONTH, Calendar.APRIL);
//		calendar.set(Calendar.DAY_OF_MONTH, 1);
//		calendar.set(Calendar.HOUR, 0);
//		calendar.set(Calendar.MINUTE, 0);
//		calendar.set(Calendar.SECOND, 0);
//		thisYearDate.setStartDate(calendar.getTime());
//		Calendar calendar1 = Calendar.getInstance();
//		calendar1.set(year + 1, Calendar.MARCH, 31);
//		calendar1.set(Calendar.HOUR, 23);
//		calendar1.set(Calendar.MINUTE, 59);
//		calendar1.set(Calendar.SECOND, 59);
//		thisYearDate.setEndDate(calendar1.getTime());
//		return thisYearDate;
//	}
//
//	public static DateModel quarter(int month, boolean isPrevYear) {
//		DateModel quarter = new DateModel();
//		Calendar calendar = Calendar.getInstance();
//		int year = calendar.get(Calendar.YEAR);
//		if (isPrevYear) {
//			year -= 1;
//		}
//		if (1 <= month && month <= 3) {
//			calendar.set(Calendar.YEAR, year);
//			calendar.set(Calendar.MONTH, Calendar.JANUARY);
//			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DATE));
//			calendar.set(Calendar.HOUR, 0);
//			calendar.set(Calendar.MINUTE, 0);
//			calendar.set(Calendar.SECOND, 0);
//			quarter.setStartDate(calendar.getTime());
//			calendar.set(Calendar.YEAR, year);
//			calendar.set(Calendar.MONTH, Calendar.MARCH);
//			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DATE));
//			calendar.set(Calendar.HOUR, 0);
//			calendar.set(Calendar.MINUTE, 0);
//			calendar.set(Calendar.SECOND, 0);
//			quarter.setEndDate(calendar.getTime());
//		} else if (4 <= month && month <= 6) {
//			calendar.set(Calendar.YEAR, year);
//			calendar.set(Calendar.MONTH, Calendar.APRIL);
//			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DATE));
//			calendar.set(Calendar.HOUR, 0);
//			calendar.set(Calendar.MINUTE, 0);
//			calendar.set(Calendar.SECOND, 0);
//			quarter.setStartDate(calendar.getTime());
//			calendar.set(Calendar.YEAR, year);
//			calendar.set(Calendar.MONTH, Calendar.JUNE);
//			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DATE));
//			calendar.set(Calendar.HOUR, 0);
//			calendar.set(Calendar.MINUTE, 0);
//			calendar.set(Calendar.SECOND, 0);
//			quarter.setEndDate(calendar.getTime());
//		} else if (7 <= month && month <= 9) {
//			calendar.set(Calendar.YEAR, year);
//			calendar.set(Calendar.MONTH, Calendar.JULY);
//			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DATE));
//			calendar.set(Calendar.HOUR, 0);
//			calendar.set(Calendar.MINUTE, 0);
//			calendar.set(Calendar.SECOND, 0);
//			quarter.setStartDate(calendar.getTime());
//			calendar.set(Calendar.YEAR, year);
//			calendar.set(Calendar.MONTH, Calendar.SEPTEMBER);
//			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DATE));
//			calendar.set(Calendar.HOUR, 0);
//			calendar.set(Calendar.MINUTE, 0);
//			calendar.set(Calendar.SECOND, 0);
//			quarter.setEndDate(calendar.getTime());
//		} else if (10 <= month && month <= 12) {
//			calendar.set(Calendar.YEAR, year);
//			calendar.set(Calendar.MONTH, Calendar.OCTOBER);
//			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DATE));
//			calendar.set(Calendar.HOUR, 0);
//			calendar.set(Calendar.MINUTE, 0);
//			calendar.set(Calendar.SECOND, 0);
//			quarter.setStartDate(calendar.getTime());
//			calendar.set(Calendar.YEAR, year);
//			calendar.set(Calendar.MONTH, Calendar.DECEMBER);
//			calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DATE));
//			calendar.set(Calendar.HOUR, 0);
//			calendar.set(Calendar.MINUTE, 0);
//			calendar.set(Calendar.SECOND, 0);
//			quarter.setEndDate(calendar.getTime());
//		}
//		return quarter;
//	}

	public static Date addMinutes(Date date, int minutes) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MINUTE, minutes);
		return calendar.getTime();
	}

	public static String getDefaultDateTimeNotYear(Date date) {
		if (date == null) {
			return "";
		}
		SimpleDateFormat dashboardDateFormat = new SimpleDateFormat("dd/MM hh:mm a");
		return dashboardDateFormat.format(date);
	}

	public static String getDefaultFileDate() {
		return getFormattedDate(new Date(), FILE_FORMAT);
	}

	public static String getFormattedDate(Object date, String pattern) {
		return getFormattedDate(date != null ? (Date) date : null, pattern);
	}

	public static synchronized String getFormattedDate(Date date, String pattern) {
		if (date == null) {
			return null;
		}
		TimeZone timeZone = TimeZone.getTimeZone("IST");
		SimpleDateFormat dateFormat = new SimpleDateFormat(pattern);
		dateFormat.setTimeZone(timeZone);
		return dateFormat.format(date);
	}

	public static Date addOrSubtractYearFromCurrentDate(Integer count) {
		if (count == null)
			return null;
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.YEAR, count);
		return cal.getTime();
	}

	public static Date updateDateToCurrentOrBeforeOneYear(Date originalDate) {
		if (originalDate == null)
			return originalDate;
		if (originalDate.after(new Date()))
			return originalDate;
		LocalDate localDate = originalDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		final int currentYear = LocalDate.now().getYear();
		final int currentMonth = LocalDate.now().getMonthValue();
		final int originalMonth = localDate.getMonthValue();

		if (originalMonth < currentMonth) {
			localDate = localDate.withYear(currentYear);
		} else if (originalMonth > currentMonth || originalMonth == currentMonth) {
			localDate = localDate.withYear(currentYear - 1);
		}

		return Date.from(localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
	}

	/**
	 * Add days to the originalDate if it is not greater than jan2020
	 * 
	 * @param originalDate
	 * @return date
	 */
	public static Date addDaysToDate(final Date originalDate) {
		if (originalDate == null)
			return originalDate;
		final LocalDate jan2020Date = LocalDate.of(2020, 1, 1);
		final LocalDate originalLocalDate = LocalDateTime.ofInstant(originalDate.toInstant(), ZoneId.systemDefault())
				.toLocalDate();
		if (originalLocalDate.isAfter(jan2020Date))
			return originalDate;
		final Long daysBetweenDates = daysBetweenTwoDates(jan2020Date, LocalDate.now());
		final LocalDateTime originalLocalDateTime = originalDate.toInstant().atZone(ZoneId.systemDefault())
				.toLocalDateTime();
		final LocalDateTime modifiedDateTime = originalLocalDateTime.plusDays(daysBetweenDates);
		return Date.from(modifiedDateTime.atZone(ZoneId.systemDefault()).toInstant());
	}

	/**
	 * Adds the difference in days between the originalDate and maxDate to the
	 * originalDate and returns the result. If originalDate is null or maxDate is
	 * null, returns null. If originalDate is after maxDate, returns originalDate.
	 *
	 * @param originalDate the original date
	 * @param maxDate      the maximum date
	 * @return the modified originalDate with the difference in days added, or
	 *         originalDate if it is after maxDate
	 */
	public static Date addDaysToDate(final Date originalDate, final Date maxDate) {
		if (originalDate == null || maxDate == null)
			return originalDate;
		if (originalDate.after(maxDate)) {
			return originalDate;
		}
		final LocalDate maxLocalDate = LocalDateTime.ofInstant(maxDate.toInstant(), ZoneId.systemDefault())
				.toLocalDate();
		final Long daysBetweenTwoDates = daysBetweenTwoDates(maxLocalDate, LocalDate.now());
		final LocalDateTime originalLocalDateTime = originalDate.toInstant().atZone(ZoneId.systemDefault())
				.toLocalDateTime();
		final LocalDateTime modifiedOriginalDate = originalLocalDateTime.plusDays(daysBetweenTwoDates);
		return Date.from(modifiedOriginalDate.atZone(ZoneId.systemDefault()).toInstant());
	}

	/**
	 * Calculates the number of days between two given dates.
	 * 
	 * @param startDate the starting date
	 * @param endDate   the ending date
	 * @return the number of days between the start and end date
	 */
	public static Long daysBetweenTwoDates(final LocalDate startDate, final LocalDate endDate) {
		return ChronoUnit.DAYS.between(startDate, endDate);
	}

	/**
	 * Checks if the given date is the current date.
	 * 
	 * @param date the date to check
	 * @return false if date is null
	 * @return true if the date is the current date, false otherwise
	 */
	public static boolean isCurrentDate(final Date date) {
		if (date == null)
			return false;
		final Calendar calendar = Calendar.getInstance();
		final Calendar calendarForDate = Calendar.getInstance();
		calendarForDate.setTime(date);

		return calendar.get(Calendar.YEAR) == calendarForDate.get(Calendar.YEAR)
				&& calendar.get(Calendar.MONTH) == calendarForDate.get(Calendar.MONTH)
				&& calendar.get(Calendar.DAY_OF_MONTH) == calendarForDate.get(Calendar.DAY_OF_MONTH);
	}

	/**
	 * Checks if a given date is between the current date and a specified number of
	 * years back. The comparison is performed based on the year, month, and day
	 * components of the dates.
	 *
	 * @param originalDate The date to check if it falls between the range.
	 * @param yearsBack    The number of years to go back in time for the lower
	 *                     bound of the range.
	 * @return {@code true} if the original date is between the current date and the
	 *         specified years back, {@code false} otherwise or if the date is null.
	 */
	public static boolean isDateWithinPastRange(Date originalDate, int yearsBack) {
		if (originalDate == null)
			return false;
		LocalDate currentDate = LocalDate.now();
		LocalDate twoYearsBack = currentDate.minusYears(yearsBack);

		LocalDate originalLocalDate = originalDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		return originalLocalDate.isAfter(twoYearsBack) && originalLocalDate.isBefore(currentDate);
	}

}
