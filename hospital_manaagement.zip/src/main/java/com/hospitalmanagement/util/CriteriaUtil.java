//package com.hospitalmanagement.util;
//
//
//
//import java.math.BigDecimal;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Collection;
//import java.util.Date;
//import java.util.List;
//
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.persistence.TypedQuery;
//import javax.persistence.criteria.CompoundSelection;
//import javax.persistence.criteria.CriteriaBuilder;
//import javax.persistence.criteria.CriteriaQuery;
//import javax.persistence.criteria.Expression;
//import javax.persistence.criteria.Order;
//import javax.persistence.criteria.Path;
//import javax.persistence.criteria.Predicate;
//import javax.persistence.criteria.Root;
//import javax.persistence.criteria.Selection;
//
//import org.springframework.data.domain.Sort;
//import org.springframework.stereotype.Component;
//import org.springframework.util.CollectionUtils;
//import org.springframework.util.StringUtils;
//
//import com.vetplus.analytics.entity.Client_;
//import com.vetplus.analytics.entity.Transaction;
//import com.vetplus.analytics.entity.Transaction_;
//import com.vetplus.common.model.PageModel;
//import com.vetplus.common.model.PaginationRequestModel;
//import com.vetplus.constants.StringConstants;
//import com.vetplus.entity.BaseEntity;
//import com.vetplus.entity.BaseEntity_;
//import com.vetplus.util.DateUtil;
//
//@Component
//public class CriteriaUtil {
//
//    @PersistenceContext
//    private EntityManager entityManager;
//
//    public void addDefaultPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
//            Root<? extends BaseEntity> root) {
//        predicates.add(criteriaBuilder.or(criteriaBuilder.isFalse(root.get(BaseEntity_.DELETED)),
//                criteriaBuilder.isNull(root.get(BaseEntity_.DELETED))));
//    }
//
//    public void addDefaultPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Path<?> root) {
//        predicates.add(criteriaBuilder.or(criteriaBuilder.isFalse(root.get(BaseEntity_.DELETED)),
//                criteriaBuilder.isNull(root.get(BaseEntity_.DELETED))));
//    }
//
//    public List<Predicate> getDefaultPredicates(CriteriaBuilder criteriaBuilder, Path<?> root) {
//        List<Predicate> predicates = new ArrayList<>();
//        addDefaultPredicates(criteriaBuilder, predicates, root);
//        return predicates;
//    }
//
//    public List<Predicate> getDefaultPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates,
//            Root<? extends BaseEntity> root) {
//        predicates.add(criteriaBuilder.or(criteriaBuilder.isFalse(root.get(BaseEntity_.DELETED)),
//                criteriaBuilder.isNull(root.get(BaseEntity_.DELETED))));
//        return predicates;
//    }
//
//    public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            String value) {
//        if (StringUtils.hasText(value)) {
//            predicates.add(criteriaBuilder.like(expression, "%" + value + "%"));
//        }
//    }
//
//    public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            Long value) {
//        if (value != null) {
//            predicates.add(criteriaBuilder.equal(expression, value));
//        }
//    }
//
//    public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            Collection<Long> list) {
//        if (!CollectionUtils.isEmpty(list)) {
//            predicates.add(criteriaBuilder.in(expression).value(list));
//        }
//    }
//
//    public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            List<Long> list, boolean isNot) {
//        if (!CollectionUtils.isEmpty(list)) {
//            Predicate in = criteriaBuilder.in(expression).value(list);
//            if (isNot) {
//                in = criteriaBuilder.not(in);
//            }
//            predicates.add(in);
//        }
//    }
//
//    public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            Long fromDate, Long toDate) {
//        if (toDate == null) {
//            toDate = new Date().getTime();
//        }
//        if (fromDate != null) {
//            Predicate between = criteriaBuilder.between(expression, DateUtil.getStartDate(new Date(fromDate)),
//                    DateUtil.getEndDate(new Date(toDate)));
//            predicates.add(between);
//        }
//    }
//
//    public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            Date date) {
//        if (date != null) {
//            Predicate between = criteriaBuilder.between(expression, DateUtil.getStartDate(date),
//                    DateUtil.getEndDate(date));
//            predicates.add(between);
//        }
//    }
//
//    public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            Enum<?> value) {
//        if (value != null) {
//            predicates.add(criteriaBuilder.equal(expression, value));
//        }
//    }
//
//    public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            Boolean value) {
//        if (value != null) {
//            predicates.add(criteriaBuilder.equal(expression, value));
//        }
//    }
//
//    public void addPredicatesIsNull(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            Boolean value) {
//        if (value != null && value) {
//            predicates.add(criteriaBuilder.isNull(expression));
//        }
//    }
//
//    public void addPredicatesIsNotNull(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            Boolean value) {
//        if (value != null && value) {
//            predicates.add(criteriaBuilder.isNotNull(expression));
//        }
//    }
//
//    public Long getCount(CriteriaBuilder criteriaBuilder, Class<?> countFromClass, List<Predicate> predicates) {
//        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
//        populateCriteriaQuery(countQuery, criteriaBuilder.countDistinct(countQuery.from(countFromClass)), predicates);
//        return entityManager.createQuery(countQuery).getSingleResult();
//    }
//
//    public boolean isCount(CriteriaQuery<?> criteriaQuery) {
//		return criteriaQuery.getResultType().equals(Long.class);
//	}
//
//    public void populateCriteriaQuery(CriteriaQuery<?> criteriaQuery, Selection selection, List<Predicate> predicates,
//            Order order) {
//        populateCriteriaQuery(criteriaQuery, selection, predicates, order != null ? Arrays.asList(order) : null);
//    }
//
//    public void populateCriteriaQuery(CriteriaQuery<?> criteriaQuery, Selection selection, List<Predicate> predicates,
//            List<Order> orders) {
//        criteriaQuery.distinct(true);
//        criteriaQuery.select(selection);
//        criteriaQuery.where(predicates.toArray(new Predicate[0]));
//        criteriaQuery.orderBy(orders);
//    }
//
//    public void populateCriteriaQuery(CriteriaQuery<?> criteriaQuery, Selection selection, List<Predicate> predicates) {
//        criteriaQuery.distinct(true);
//        criteriaQuery.select(selection);
//        criteriaQuery.where(predicates.toArray(new Predicate[0]));
//    }
//    
//    public void populateCriteriaQuery(CriteriaQuery<?> criteriaQuery, Selection selection) {
//        criteriaQuery.distinct(true);
//        criteriaQuery.select(selection);
//    }
//
//    public PageModel getPageModel(TypedQuery typedQuery, Long totalCount,
//            PaginationRequestModel paginationModel) {
//        PaginationUtil.setPaginationToQuery(typedQuery, paginationModel);
//
//        Long pageCount = 0L;
//        List<?> data = new ArrayList<>();
//
//        if (totalCount > 0) {
//            data = typedQuery.getResultList();
//            pageCount = totalCount / typedQuery.getMaxResults();
//            if (totalCount % typedQuery.getMaxResults() > 0) {
//                pageCount++;
//            }
//        }
//        return PageModel.builder().data(data).pageCount(pageCount).totalCount(totalCount).build();
//    }
//
//    public PageModel getPageModel(CriteriaBuilder criteriaBuilder, CriteriaQuery<?> criteriaQuery,
//            Class<?> countFromClass, Selection selection, List<Predicate> predicates, Order order,
//            PaginationRequestModel paginationModel) {
//
//        criteriaQuery.distinct(true);
//        criteriaQuery.select(selection);
//        criteriaQuery.where(predicates.toArray(new Predicate[0]));
//        criteriaQuery.orderBy(order);
//
//        TypedQuery typedQuery = entityManager.createQuery(criteriaQuery);
//        PaginationUtil.setPaginationToQuery(typedQuery, paginationModel);
//
//        CriteriaQuery<Long> countQuery = criteriaBuilder.createQuery(Long.class);
//        countQuery.select(criteriaBuilder.countDistinct(countQuery.from(countFromClass)));
//        countQuery.where(predicates.toArray(new Predicate[0]));
//        Long totalCount = entityManager.createQuery(countQuery).getSingleResult();
//
//        Long pageCount = 0L;
//        List<?> data = new ArrayList<>();
//
//        if (totalCount > 0) {
//            data = typedQuery.getResultList();
//            pageCount = totalCount / typedQuery.getMaxResults();
//            if (totalCount % typedQuery.getMaxResults() > 0) {
//                pageCount++;
//            }
//        }
//        return PageModel.builder().data(data).pageCount(pageCount).totalCount(totalCount).build();
//    }
//
//    public List<?> getList(CriteriaQuery<?> criteriaQuery, Selection<?> selection, List<Predicate> predicates,
//            Order order) {
//        populateCriteriaQuery(criteriaQuery, selection, predicates, order);
//        TypedQuery<?> typedQuery = entityManager.createQuery(criteriaQuery);
//        return typedQuery.getResultList();
//    }
//    
//    public List<?> getList(CriteriaQuery<?> criteriaQuery, Selection<?> selection, List<Predicate> predicates,
//            List<Order> orders) {
//        populateCriteriaQuery(criteriaQuery, selection, predicates, orders);
//        TypedQuery<?> typedQuery = entityManager.createQuery(criteriaQuery);
//        return typedQuery.getResultList();
//    }
//
//    public PageModel getPageModel(CriteriaQuery<?> listQuery, CriteriaQuery<Long> countQuery,
//            PaginationRequestModel pagination) {
//        TypedQuery<?> listTypedQuery = entityManager.createQuery(listQuery);
//        TypedQuery<Long> countTypedQuery = entityManager.createQuery(countQuery);
//
//        PaginationUtil.setPaginationToQuery(listTypedQuery, pagination);
//
//        List<?> list = listTypedQuery.getResultList();
//        Long totalCount = !CollectionUtils.isEmpty(list)
//                ? countTypedQuery.getSingleResult()
//                : 0L;
//
//        return getPageModel(list, totalCount, listTypedQuery.getMaxResults());
//    }
//
//    public PageModel getPageModel(List<?> list, Long totalCount, Integer pageSize) {
//        Long pageCount = 0L;
//        if (totalCount > 0) {
//            pageCount = totalCount / pageSize;
//            if (totalCount % pageSize > 0) {
//                pageCount++;
//            }
//        }
//        return PageModel.builder().data(list).pageCount(pageCount).totalCount(totalCount).build();
//    }
//
//	public <T> T getSingleResult(CriteriaQuery<T> criteriaQuery, Selection<?> selection, List<Predicate> predicates) {
//		populateCriteriaQuery(criteriaQuery, selection, predicates);
//		return entityManager.createQuery(criteriaQuery).getSingleResult();
//	}
//
//	public void addPredicatesEqual(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//			String value) {
//		if (StringUtils.hasText(value)) {
//			predicates.add(criteriaBuilder.equal(expression, value));
//		}
//	}
//
//
//	public Order getDefaultOrder(CriteriaBuilder criteriaBuilder, String sortBy, Sort.Direction direction,
//			Root<?> root) {
//		Order order = null;
//		if (sortBy == null) {
//			sortBy = BaseEntity_.CREATED_ON;
//			Expression<?> ex = criteriaBuilder.selectCase()
//					.when(root.get(BaseEntity_.UPDATED_ON).isNull(), root.get(sortBy))
//					.otherwise(root.get(BaseEntity_.UPDATED_ON));
//			order = criteriaBuilder.desc(ex);
//		} else if (Sort.Direction.ASC.equals(direction)) {
//			order = criteriaBuilder.asc(root.get(sortBy));
//		} else {
//			order = criteriaBuilder.desc(root.get(sortBy));
//		}
//		return order;
//	}
//
//	public List<?> getDropdownRespone(CriteriaQuery<?> criteriaQuery,
//			CompoundSelection<?> selection, List<Predicate> predicates, Order order) {
//		populateCriteriaQuery(criteriaQuery, selection, predicates, order);
//		return entityManager.createQuery(criteriaQuery).setMaxResults(10).getResultList();
//	}
//
//	public void addPredicatesEqual(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Path<?> expression,
//			BigDecimal value) {
//		if (value != null) {
//            predicates.add(criteriaBuilder.equal(expression, value));
//        }
//    }
//
//	public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Path<Object> expression,
//			BigDecimal price) {
//		if (price != null) {
//            predicates.add(criteriaBuilder.equal(expression, price));
//        }
//    }
//
//    public void addPredicatesIn(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//                                List<?> list) {
//        if (!CollectionUtils.isEmpty(list)) {
//            predicates.add(criteriaBuilder.in(expression).value(list));
//        }
//    }
//    
//    public void addPredicatesNotIn(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression, Collection<Long> list) {
//        if (!CollectionUtils.isEmpty(list)) {
//            predicates.add(criteriaBuilder.not(criteriaBuilder.in(expression).value(list)));
//        }
//    }
//    
//    public void addPredicates(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression,
//            Double value) {
//        if (value != null) {
//            predicates.add(criteriaBuilder.equal(expression, value));
//        }
//    }
//
//	public void addPredicatesNotLike(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList, Expression expression,
//			String value) {
//		if (value != null) {
//			predicateList.add(criteriaBuilder.notLike(expression, value));
//		}
//	}
//
//	public void addPredicatesNotNull(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList,
//			Expression<?> expression) {
//		predicateList.add(criteriaBuilder.isNotNull(expression));
//		
//	}
//
//	public void addPredicatesNotEqual(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList,
//			Expression<?> expression, String value) {
//		predicateList.add(criteriaBuilder.notEqual(expression, value));
//	}
//	
//	public List<Predicate> getDefaultDescriptionPredicateList(CriteriaBuilder criteriaBuilder,
//			Root<Transaction> root) {
//		List<Predicate> predicateList = new ArrayList<>();
//		this.addPredicatesNotLike(criteriaBuilder, predicateList, root.get(Transaction_.DESCRIPTION),
//				StringConstants.PAYMENT);
//		this.addPredicatesNotLike(criteriaBuilder, predicateList, root.get(Transaction_.DESCRIPTION),
//				StringConstants.REFUND);
//		this.addPredicatesNotLike(criteriaBuilder, predicateList, root.get(Transaction_.DESCRIPTION),
//				StringConstants.CREDIT);
//		this.addPredicatesNotLike(criteriaBuilder, predicateList, root.get(Transaction_.DESCRIPTION),
//				StringConstants.MASTERCARD);
//		this.addPredicatesNotLike(criteriaBuilder, predicateList, root.get(Transaction_.DESCRIPTION),
//				StringConstants.VISA);
//		this.addPredicatesNotLike(criteriaBuilder, predicateList,
//				root.get(Transaction_.DESCRIPTION),
//				StringConstants.AMERICAN_EXPRESS);
//		this.addPredicatesNotNull(criteriaBuilder, predicateList, root.get(Transaction_.DESCRIPTION));
//		this.addPredicatesNotEqual(criteriaBuilder, predicateList, root.get(Transaction_.DESCRIPTION), "");
//		return predicateList;
//	}
//
//	public void addPredicatesBetween(CriteriaBuilder criteriaBuilder, List<Predicate> predicateList,Root<Transaction> root,
//			Date startDate, Date endDate) {
//		if (startDate != null && endDate != null) {
//			predicateList.add(criteriaBuilder.between(root.get(Transaction_.TRANSACTION_DATE), startDate, endDate));
//		}		
//	}
//	
//	public void addSpecialCharactersPredicate(CriteriaBuilder criteriaBuilder, List<Predicate> predicates, Expression expression) {
//		List<String> regexList = Arrays.asList("$%", "?%",".%", "-%", "(%", " %", "0%", "1%", "2%", "3%", "4%", "5%",
//				"6%", "7%", "8%", "9%","\"%", "!%", "*%", "#%" , "`%",  ")%", "~%", "<%", ">%","%________%");
//		for (String regex : regexList) {
//			predicates.add(criteriaBuilder.notLike(expression, regex));			
//		}
//	}
//	
//	public <T> List<T> getGenericList(CriteriaQuery<T> criteriaQuery, Selection<?> selection, List<Predicate> predicates,
//	        Order order) {
//	    populateCriteriaQuery(criteriaQuery, selection, predicates, order);
//	    TypedQuery<T> typedQuery = entityManager.createQuery(criteriaQuery);
//	    return typedQuery.getResultList();
//	}
//
//
//}
