package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Test;
import com.hospitalmanagement.response.TestResponse;

@Component
public class TestHelper {

	public TestResponse getTestResponse(Test test) {
		return TestResponse.builder().id(test.getId()).build();
	}

}
