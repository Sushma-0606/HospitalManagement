package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Transaction;
import com.hospitalmanagement.response.TransactionResponse;

@Component
public class TransactionHelper {

	public TransactionResponse getTransactionResponse(Transaction transaction) {
		return TransactionResponse.builder().id(transaction.getId())
				.build();
	}
}
