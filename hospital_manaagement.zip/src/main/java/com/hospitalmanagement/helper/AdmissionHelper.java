package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Admission;
import com.hospitalmanagement.response.AdmissionResponse;

@Component
public class AdmissionHelper {
	
	public AdmissionResponse getAdmissionResponse(Admission admission) {
		if (admission == null)
			return null;
		return AdmissionResponse.builder().id(admission.getId())
				.patientId(admission.getPatient() != null ? admission.getPatient().getId() : null)
				.wardId(admission.getWard() != null ? admission.getWard().getId() : null)
				.admissionDateTime(admission.getAdmissionDateTime()).dischargeDateTime(admission.getDischargeDateTime())
				.build();
	}

}
