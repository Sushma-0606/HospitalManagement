package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Appointment;
import com.hospitalmanagement.response.AppointmentResponse;

@Component
public class AppointmentHelper {

	public AppointmentResponse getAppointmentResponse(Appointment appointment) {
		if (appointment == null)
			return null;
		return AppointmentResponse.builder().id(appointment.getId()).build();
	}
}
