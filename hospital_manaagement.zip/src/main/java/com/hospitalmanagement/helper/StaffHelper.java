package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Staff;
import com.hospitalmanagement.response.StaffResponse;

@Component
public class StaffHelper {

	public StaffResponse getStaffResponse(Staff staff) {
		return StaffResponse.builder().id(staff.getId()).build();
	}
}
