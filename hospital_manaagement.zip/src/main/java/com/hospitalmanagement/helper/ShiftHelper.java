package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Shift;
import com.hospitalmanagement.response.ShiftResponse;

@Component
public class ShiftHelper {

	public ShiftResponse getShiftResponse(Shift shift) {
		return ShiftResponse.builder().id(shift.getId()).build();
	}
}
