package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Billing;
import com.hospitalmanagement.response.BillingResponse;

@Component
public class BillingHelper {

	public BillingResponse getBillingResponse(Billing billing) {
		if (billing == null)
			return null;
		return BillingResponse.builder().id(billing.getId()).build();
	}

}
