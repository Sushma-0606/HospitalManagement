package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Prescription;
import com.hospitalmanagement.response.PrescriptionResponse;

@Component
public class PrescriptionHelper {

	public PrescriptionResponse getPrescriptionResponse(Prescription prescription) {
		return PrescriptionResponse.builder().id(prescription.getId()).build();
	}
}
