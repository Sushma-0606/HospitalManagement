package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.User;
import com.hospitalmanagement.response.UserResponse;

@Component
public class UserHelper {

	public UserResponse getUserResponse(User user) {
		return UserResponse.builder().id(user.getId()).username(user.getUsername())
				.password(user.getPassword()).createdOn(user.getCreatedOn())
				.build();
	}

}
