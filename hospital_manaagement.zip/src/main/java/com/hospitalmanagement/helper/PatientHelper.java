package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Patient;
import com.hospitalmanagement.response.PatientResponse;

@Component
public class PatientHelper {

	public PatientResponse getPatientResponse(Patient patient) {
		return PatientResponse.builder().id(patient.getId()).build();
	}
}
