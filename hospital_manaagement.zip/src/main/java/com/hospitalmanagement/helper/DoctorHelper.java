package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Doctor;
import com.hospitalmanagement.response.DoctorResponse;

@Component
public class DoctorHelper {

	public DoctorResponse getDoctorResponse(Doctor doctor) {
		if (doctor == null)
			return null;
		return DoctorResponse.builder().id(doctor.getId()).build();
	}
}
