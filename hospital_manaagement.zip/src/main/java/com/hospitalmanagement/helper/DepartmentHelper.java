package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Department;
import com.hospitalmanagement.response.DepartmentResponse;

@Component
public class DepartmentHelper {

	public DepartmentResponse getDepartmentResponse(Department department) {
		if (department == null)
			return null;
		return DepartmentResponse.builder().id(department.getId()).name(department.getName()).build();
	}
}
