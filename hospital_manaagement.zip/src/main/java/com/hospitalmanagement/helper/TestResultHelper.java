package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.TestResult;
import com.hospitalmanagement.response.TestResultResponse;

@Component
public class TestResultHelper {

	public TestResultResponse getTestResultResponse(TestResult testResult) {
		return TestResultResponse.builder().id(testResult.getId()).build();
	}
}
