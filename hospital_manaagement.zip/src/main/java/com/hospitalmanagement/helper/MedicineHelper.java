package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Medicine;
import com.hospitalmanagement.response.MedicineResposne;

@Component
public class MedicineHelper {

	public MedicineResposne getMedicineResposne(Medicine medicine) {
		if (medicine == null)
			return null;
		return MedicineResposne.builder().id(medicine.getId()).build();
	}
}
