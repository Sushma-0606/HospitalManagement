package com.hospitalmanagement.helper;

import org.springframework.stereotype.Component;

import com.hospitalmanagement.entity.Ward;
import com.hospitalmanagement.response.WardResponse;

@Component
public class WardHelper {

	public WardResponse getWardResponse(Ward ward) {
		return WardResponse.builder().id(ward.getId()).build();
	}
}
